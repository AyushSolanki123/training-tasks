class ErrorBody {
  constructor (statusCode, errorMessage) {
    this.statusCode = statusCode
    this.errorMessage = errorMessage
  }
}

module.exports = ErrorBody
