const express = require("express");
const router = express.Router();
const { body } = require("express-validator");

// controller
const todoController = require("../Controllers/TodoController");

router.get("/", todoController.listTodos);

router.get("/:todoId", todoController.getTodoById);

router.get("/search/:search", todoController.searchTodo);

router.post(
  "/",
  [body("title").notEmpty(), body("description").notEmpty()],
  todoController.addTodo
);

router.put("/:todoId", todoController.updateTodo);

router.delete("/:todoId", todoController.deleteTodo);

module.exports = router;
