const router = require("express").Router();

router.use("/todo", require("./TodoRoutes"));

router.get("/", (req, res) => {
  res.redirect("/api/v1");
});

module.exports = router;
