const { validationResult } = require("express-validator");
const TodoService = require("../Services/TodoService");
const ErrorBody = require("../Utils/ErrorBody");
const { logger } = require("../Utils/Logger");

function addTodo(req, res, next) {
  const { errors } = validationResult(req);
  if (errors.length > 0) {
    logger.error("Error in adding todo: " + JSON.stringify(errors));
    throw new ErrorBody(400, "Invalid values in form");
  } else {
    TodoService.addTodo(req.body)
      .then((response) => {
        res.status(201);
        res.json({
          data: response,
          message: "Todo added successfully",
        });
      })
      .catch((error) => {
        logger.error("Failed in add todo: " + JSON.stringify(error.message));
        next(
          new ErrorBody(
            error.status || 500,
            error.message || "Internal Server Error"
          )
        );
      });
  }
}

function listTodos(req, res, next) {
  TodoService.listTodos()
    .then((response) => {
      res.status(200);
      res.json({
        data: response,
        message: "Todos fetched successfully",
      });
    })
    .catch((error) => {
      logger.error("Failed in list todo: " + JSON.stringify(error.message));
      next(
        new ErrorBody(
          error.status || 500,
          error.message || "Internal Server Error"
        )
      );
    });
}

function getTodoById(req, res, next) {
  const { todoId } = req.params;
  TodoService.getTodoById(todoId)
    .then((response) => {
      res.status(200);
      res.json({
        data: response,
        message: "Todo fetched successfully",
      });
    })
    .catch((error) => {
      logger.error(
        "Failed in get todo by id: " + JSON.stringify(error.message)
      );
      next(
        new ErrorBody(
          error.status || 500,
          error.message || "Internal Server Error"
        )
      );
    });
}

function updateTodo(req, res, next) {
  const { todoId } = req.params;
  TodoService.updateTodo(todoId, req.body)
    .then((response) => {
      res.status(200);
      res.json({
        data: response,
        message: "Todo updated successfully",
      });
    })
    .catch((error) => {
      logger.error("Failed in update todo: " + JSON.stringify(error.message));
      next(
        new ErrorBody(
          error.status || 500,
          error.message || "Internal Server Error"
        )
      );
    });
}

function deleteTodo(req, res, next) {
  const { todoId } = req.params;
  TodoService.deleteTodo(todoId)
    .then((response) => {
      res.status(200);
      res.json({
        data: response,
        message: "Todo deleted successfully",
      });
    })
    .catch((error) => {
      logger.error("Failed in delete todo: " + JSON.stringify(error.message));
      next(
        new ErrorBody(
          error.status || 500,
          error.message || "Internal Server Error"
        )
      );
    });
}

function searchTodo(req, res, next) {
  const { search } = req.params;
  TodoService.searchTodo(search)
    .then((response) => {
      res.status(200);
      res.json({
        data: response,
        message: "Todos fetched successfully",
      });
    })
    .catch((error) => {
      logger.error("Failed in Search todo: " + JSON.stringify(error.message));
      next(
        new ErrorBody(
          error.status || 500,
          error.message || "Internal Server Error"
        )
      );
    });
}

module.exports = {
  addTodo: addTodo,
  listTodos: listTodos,
  getTodoById: getTodoById,
  updateTodo: updateTodo,
  deleteTodo: deleteTodo,
  searchTodo: searchTodo,
};
