const { default: mongoose } = require("mongoose");
const ErrorBody = require("../Utils/ErrorBody");

const Todo = require("../Models/Todo").model;

function addTodo(reqBody) {
  return new Promise((resolve, reject) => {
    let _reqBody = reqBody;
    Todo.find()
      .count()
      .then((count) => {
        _reqBody = Object.assign(_reqBody, { id: count + 1 });
        return Todo.create(_reqBody);
      })
      .then((response) => resolve(response))
      .catch((error) => {
        console.log(error);
        reject(new ErrorBody(500, error.message || "Internal Server Error"));
      });
  });
}

function listTodos() {
  return Todo.find({ isDeleted: false });
}

function getTodoById(id) {
  return Todo.findOne({ id: id, isDeleted: false });
}

function updateTodo(id, reqBody) {
  return Todo.findOneAndUpdate(
    { id: id },
    { $set: { ...reqBody } },
    { new: true }
  );
}

function deleteTodo(id) {
  return Todo.findOneAndUpdate(
    { id: id },
    { $set: { isDeleted: true } },
    { new: true }
  );
}

function searchTodo(title) {
  return Todo.aggregate([
    {
      $match: {
        title: {
          $regex: title,
          $options: "i",
        },
        isDeleted: false,
      },
    },
  ]);
}

module.exports = {
  addTodo: addTodo,
  listTodos: listTodos,
  getTodoById: getTodoById,
  updateTodo: updateTodo,
  deleteTodo: deleteTodo,
  searchTodo: searchTodo,
};
