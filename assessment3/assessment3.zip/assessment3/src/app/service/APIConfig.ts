export default {
  baseURL: 'http://localhost:4000/todo',
  listTodo: '/',
  addTodo: '/',
  getTodo: '/{todoId}',
  updateTodo: '/{todoId}',
  deleteTodo: '/{todoId}',
  searchTodo: '/search/{title}',
};
