export interface Todo {
  _id?: string;
  id?: number;
  title?: string;
  description?: string;
  isCompleted?: boolean;
  isDeleted?: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface ListTodoGroup {
  data: Todo[];
  message: string;
}

export interface TodoGroup {
  data: Todo;
  message: string;
}
