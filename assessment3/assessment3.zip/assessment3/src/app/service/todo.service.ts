import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ListTodoGroup, Todo, TodoGroup } from './Todo';
import APIConfig from './APIConfig';

@Injectable({
  providedIn: 'root',
})
export class TodoService {
  constructor(private httpClient: HttpClient) {}

  listTodos(): Observable<ListTodoGroup> {
    return this.httpClient.get<ListTodoGroup>(
      APIConfig.baseURL + APIConfig.listTodo
    );
  }

  getTodoById(id: number): Observable<TodoGroup> {
    return this.httpClient.get<TodoGroup>(
      APIConfig.baseURL + APIConfig.getTodo.replace('{todoId}', `${id}`)
    );
  }

  addTodo(todo: Todo): Observable<TodoGroup> {
    return this.httpClient.post<TodoGroup>(
      APIConfig.baseURL + APIConfig.addTodo,
      todo
    );
  }

  updateTodo(id: number, todo: Todo): Observable<TodoGroup> {
    return this.httpClient.put<TodoGroup>(
      APIConfig.baseURL + APIConfig.updateTodo.replace('{todoId}', `${id}`),
      todo
    );
  }

  deleteTodo(id: number): Observable<TodoGroup> {
    return this.httpClient.delete<TodoGroup>(
      APIConfig.baseURL + APIConfig.deleteTodo.replace('{todoId}', `${id}`)
    );
  }

  searchTodo(title: string): Observable<ListTodoGroup> {
    return this.httpClient.get<ListTodoGroup>(
      APIConfig.baseURL + APIConfig.searchTodo.replace('{title}', `${title}`)
    );
  }
}
