import { Component, OnInit } from '@angular/core';
import { TodoService } from 'src/app/service/todo.service';
import { Observable, of, switchMap, tap } from 'rxjs';
import { Todo } from 'src/app/service/Todo';
import { selectTodos } from 'src/app/store/selectors/todo.selector';
import { AppState } from 'src/app/store';
import { deleteTodo, fetchTodos } from 'src/app/store/actions/todo.action';
import { Store } from '@ngrx/store';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-todos',
  templateUrl: './list-todos.component.html',
  styleUrls: ['./list-todos.component.scss'],
})
export class ListTodosComponent implements OnInit {
  loading: boolean = true;
  todos: Todo[] = [];
  search: string = '';
  resetState: boolean = false;

  constructor(
    private store: Store<AppState>,
    private todoService: TodoService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.todoService.listTodos().subscribe(
      (response) => {
        this.store.dispatch(fetchTodos({ todos: response.data }));
        this.store
          .select(selectTodos)
          .pipe(
            switchMap((todos) => {
              if (todos) {
                return of(todos);
              } else {
                return this.store.select(selectTodos);
              }
            })
          )
          .subscribe((value) => {
            this.todos = value;
            this.loading = false;
          });
      },
      (error) => {
        console.log(error);
        this.loading = false;
      }
    );
  }

  onAddTodo(): void {
    this.router.navigateByUrl('/add-todo');
  }

  onChangeStatus(data: { todo: Todo; status: boolean }) {
    this.loading = true;
    const id = <number>data.todo.id;
    const reqBody = {
      isCompleted: data.status,
    };
    this.todoService.updateTodo(id, reqBody).subscribe(
      (value) => {
        this.todos = this.todos.map((t) => (t.id == id ? value.data : t));
        this.loading = false;
      },
      (error) => {
        console.log(error);
        this.loading = false;
      }
    );
  }

  onUpdateTodo(id: number) {
    this.router.navigateByUrl(`/update-todo/${id}`);
  }

  onDeleteTodo(id: number) {
    this.loading = true;
    this.todoService.deleteTodo(id).subscribe(
      () => {
        this.store.dispatch(deleteTodo({ id }));
        this.store
          .select(selectTodos)
          .pipe(
            switchMap((todos) => {
              if (todos) {
                return of(todos);
              } else {
                return this.store.select(selectTodos);
              }
            })
          )
          .subscribe((value) => {
            this.todos = value;
            this.loading = false;
          });
      },
      (error) => {
        console.log(error);
        this.loading = false;
      }
    );
  }

  onSearchTodo() {
    this.loading = true;
    this.resetState = true;
    this.todoService.searchTodo(this.search).subscribe(
      (response) => {
        this.todos = response.data;
        this.search = '';
        this.loading = false;
      },
      (error) => {
        console.log(error);
        this.todoService.listTodos().subscribe(
          (response) => {
            this.store.dispatch(fetchTodos({ todos: response.data }));
            this.store
              .select(selectTodos)
              .pipe(
                switchMap((todos) => {
                  if (todos) {
                    return of(todos);
                  } else {
                    return this.store.select(selectTodos);
                  }
                })
              )
              .subscribe((value) => {
                this.todos = value;
                this.search = '';
                this.loading = false;
              });
          },
          (error) => {
            console.log(error);
            this.search = '';
            this.loading = false;
          }
        );
      }
    );
  }

  onResetState() {
    this.loading = true;
    this.todoService.listTodos().subscribe(
      (response) => {
        this.store.dispatch(fetchTodos({ todos: response.data }));
        this.store
          .select(selectTodos)
          .pipe(
            switchMap((todos) => {
              if (todos) {
                return of(todos);
              } else {
                return this.store.select(selectTodos);
              }
            })
          )
          .subscribe((value) => {
            this.todos = value;
            this.search = '';
            this.resetState = false;
            this.loading = false;
          });
      },
      (error) => {
        console.log(error);
        this.search = '';
        this.resetState = false;
        this.loading = false;
      }
    );
  }
}
