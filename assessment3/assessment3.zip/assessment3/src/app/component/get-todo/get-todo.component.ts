import { Component } from '@angular/core';

@Component({
  selector: 'app-get-todo',
  templateUrl: './get-todo.component.html',
  styleUrls: ['./get-todo.component.scss']
})
export class GetTodoComponent {

}
