import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { ListTodosComponent } from './component/list-todos/list-todos.component';
import { AddTodoComponent } from './component/add-todo/add-todo.component';
import { UpdateTodoComponent } from './component/update-todo/update-todo.component';
import { GetTodoComponent } from './component/get-todo/get-todo.component';
import { StoreModule } from '@ngrx/store';
import { reducers, metaReducers } from './store';
import { ListTodoTableComponent } from './component/list-todo-table/list-todo-table.component';

@NgModule({
  declarations: [
    AppComponent,
    ListTodosComponent,
    AddTodoComponent,
    UpdateTodoComponent,
    GetTodoComponent,
    ListTodoTableComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    StoreModule.forRoot(reducers, { metaReducers }),
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
