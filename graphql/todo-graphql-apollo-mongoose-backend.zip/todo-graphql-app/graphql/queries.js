const Todo = require("../models/Todo").model;

const queries = {
    todos: async () => {
        const todoWithUsers = await Todo.find();
        return todoWithUsers.map((todo) => {
            return {
                ...todo._doc,
                _id: todo._id.toString(),
            };
        });
    },
    getTodo: async (_, { _id }) => {
        const todo = await Todo.findById(_id);
        return {
            ...todo._doc,
            _id: todo._id.toString(),
        };
    },
};

module.exports = queries;
