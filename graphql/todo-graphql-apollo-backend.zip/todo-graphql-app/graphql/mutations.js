const { todos, users } = require("../data");
const { v4: uuidv4 } = require("uuid");

const mutations = {
    addTodo: (parent, { input }, { pubsub }) => {
        const newTodo = { id: uuidv4(), ...input };
        todos.push(newTodo);
        pubsub.publish("todo", {
            todo: {
                mutation: "CREATE_TODO",
                data: newTodo,
            },
        });
        return newTodo;
    },
    updateTodo: (parent, { input }, { pubsub }) => {
        const todoIndex = todos.findIndex((todo) => todo.id === input.id);
        if (todoIndex === -1) {
            throw new Error(`Todo with id ${input.id} not found`);
        }
        const updatedTodo = { ...todos[todoIndex], ...input };
        todos[todoIndex] = updatedTodo;
        pubsub.publish("todo", {
            todo: {
                mutation: "UPDATE_TODO",
                data: updatedTodo,
            },
        });
        return updatedTodo;
    },
    deleteTodo: (parent, { id }, { pubsub }) => {
        const todoIndex = todos.findIndex((todo) => todo.id === id);
        if (todoIndex === -1) {
            throw new Error(`Todo with id ${id} not found`);
        }
        const deletedTodo = todos.splice(todoIndex, 1)[0];
        pubsub.publish("todo", {
            todo: {
                mutation: "DELETE_TODO",
                data: deletedTodo,
            },
        });
        return deletedTodo;
    },
    addUser: (parent, { input }, { pubsub }) => {
        const newUser = { id: uuidv4(), ...input };
        users.push(newUser);
        pubsub.publish("user", {
            user: {
                mutation: "CREATE_USER",
                data: newUser,
            },
        });
        return newUser;
    },
    updateUser: (parent, { input }, { pubsub }) => {
        const userIndex = users.findIndex((user) => user.id === input.id);
        if (userIndex === -1) {
            throw new Error(`User with id ${input.id} not found`);
        }
        const updatedUser = { ...users[userIndex], ...input };
        users[userIndex] = updatedUser;
        pubsub.publish("user", {
            user: {
                mutation: "UPDATE_USER",
                data: updatedUser,
            },
        });
        return updatedUser;
    },
    deleteUser: (parent, { id }, { pubsub }) => {
        const userIndex = users.findIndex((user) => user.id === id);
        if (userIndex === -1) {
            throw new Error(`User with id ${id} not found`);
        }
        const deletedUser = users.splice(userIndex, ``)[0];
        pubsub.publish("user", {
            user: {
                mutation: "DELETE_USER",
                data: deletedUser,
            },
        });
        return deletedUser;
    },
};

module.exports = mutations;
