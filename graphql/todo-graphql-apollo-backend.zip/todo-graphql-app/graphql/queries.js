const { todos, users } = require("../data");

const queries = {
    todos: () => {
        const todosWithUsers = todos.map((todo) => {
            const user = users.find((u) => u.id === todo.userId);
            return { ...todo, user };
        });
        return todosWithUsers;
    },
    getTodo: (parent, { id }) => todos.find((t) => t.id === id),
    users: () => users,
    getUser: (parent, { id }) => users.find((u) => u.id === id),
};

module.exports = queries;
