const todos = [
    {
        id: "todo-1",
        title: "Todo 1",
        description: "Test Todo 1",
        dueDate: "2023-03-10",
        completed: true,
        user: "user-1",
    },
    {
        id: "todo-2",
        title: "Todo 2",
        description: "Test Todo 2",
        completed: false,
        dueDate: "2023-03-11",
        user: "user-1",
    },
    {
        id: "todo-3",
        title: "Todo 3",
        description: "Test Todo 3",
        completed: true,
        dueDate: "2023-03-10",
        user: "user-2",
    },
];

const users = [
    {
        id: "user-1",
        name: "User 1",
        dob: "2001-08-19",
    },
    {
        id: "user-2",
        name: "User 2",
        dob: "2001-09-19",
    },
];

exports.todos = todos;
exports.users = users;
