const express = require("express");
const http = require("http");
const { ApolloServer } = require("apollo-server-express");
const { execute, subscribe } = require("graphql");
const { SubscriptionServer } = require("subscriptions-transport-ws");
const { makeExecutableSchema } = require("@graphql-tools/schema");
const { PubSub } = require("graphql-subscriptions");
const { typeDefs, resolver } = require("./graphql");

const pubsub = new PubSub();

const SubscriptionResolvers = {
    Subscription: {
        todo: {
            subscribe: () => pubsub.asyncIterator("todo"),
        },
        user: {
            subscribe: () => pubsub.asyncIterator("user"),
        },
    },
};

const server = new ApolloServer({
    typeDefs,
    resolvers: [resolver, SubscriptionResolvers],
    context: ({ req, connection }) => {
        if (connection) {
            return { pubsub };
        } else {
            return { req, pubsub };
        }
    },
});

async function startServer() {
    await server.start();

    // Create a new instance of Express
    const app = express();

    // Apply the Apollo middleware to the Express app
    server.applyMiddleware({ app });

    // Create an HTTP server instance
    const httpServer = http.createServer(app);

    // Create a Schema
    const schema = makeExecutableSchema({
        typeDefs,
        resolvers: [resolver, SubscriptionResolvers],
    });

    // Start the server
    httpServer.listen({ port: 4000 }, () => {
        console.log(
            `🚀 Server ready at http://localhost:4000${server.graphqlPath}`
        );

        // Create a Subscription Server instance
        new SubscriptionServer(
            {
                execute,
                subscribe,
                schema: schema,
                onConnect: () => console.log("Connected to websocket"),
            },
            {
                server: httpServer,
                path: server.graphqlPath,
            }
        );
    });
}

startServer();
