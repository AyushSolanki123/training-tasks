import { TestingPipe } from './testing.pipe';

describe('TestingPipe', () => {
  it('create an instance', () => {
    const pipe = new TestingPipe();
    expect(pipe).toBeTruthy();
  });

  it('check Uppercase', () => {
    const pipe = new TestingPipe();
    const input = 'hello world';
    expect(pipe.transform(input, 'U')).toMatch('HELLO WORLD');
  });

  it('check lowercase', () => {
    const pipe = new TestingPipe();
    const input = 'HELLO WORLD';
    expect(pipe.transform(input, 'L')).toMatch('hello world');
  });

  it('check titlecase', () => {
    const pipe = new TestingPipe();
    const input = 'hello worLd';
    expect(pipe.transform(input, 'T')).toMatch('Hello WorLd');
  });

  it('check elsecase', () => {
    const pipe = new TestingPipe();
    const input = 'Hello world';
    expect(pipe.transform(input, 'A')).toMatch(input);
  });
});
