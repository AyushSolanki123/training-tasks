import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'testing',
})
export class TestingPipe implements PipeTransform {
  transform(value: string, args: string): any {
    if (args == 'U') {
      return value.toUpperCase();
    } else if (args == 'L') {
      return value.toLowerCase();
    } else if (args == 'T') {
      var i = 0;
      var titleCase = '';
      var words = value.split(' ');
      for (let word of words) {
        word = word.charAt(0).toUpperCase() + word.slice(1);
        titleCase += ' ' + word;
      }
      return titleCase;
    } else {
      return value;
    }
  }
}
