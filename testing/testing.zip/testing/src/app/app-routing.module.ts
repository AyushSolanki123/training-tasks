import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TestingComponent } from './component/testing/testing.component';

const routes: Routes = [
  {
    path: 'testing',
    component: TestingComponent,
  },
  {
    path: '',
    redirectTo: '/testing',
    pathMatch: 'full',
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
