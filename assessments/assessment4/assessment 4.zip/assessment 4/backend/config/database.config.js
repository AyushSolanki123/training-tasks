module.exports = {
    url: "mongodb+srv://admin:T6TGuTj67F3kzeTD@test.btkcimo.mongodb.net/test",
};
