import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoadingModule } from 'src/app/loading/loading.module';
import { ViewDetailsRoutingModule } from './view-details-routing.module';

import { ViewDetailsComponent } from './view-details.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [ViewDetailsComponent],
  imports: [CommonModule, LoadingModule, ViewDetailsRoutingModule, FormsModule],
})
export class ViewDetailsModule {}
