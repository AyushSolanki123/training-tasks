import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import {
  APIService,
  Booking,
  TicketType,
  UpdateBookingInput,
} from 'src/app/API.service';
import { FlightService } from 'src/app/service/flight/flight.service';
import { AppState } from 'src/app/store';
import {
  deleteBooking,
  fetchBookings,
  updateBooking,
} from 'src/app/store/actions/flight.actions';
import { selectBookings } from 'src/app/store/selectors/flight.selectors';

@Component({
  selector: 'app-view-details',
  templateUrl: './view-details.component.html',
  styleUrls: ['./view-details.component.scss'],
})
export class ViewDetailsComponent implements OnInit {
  loading: boolean = true;
  currentBooking!: Booking;
  bookings$: Observable<Booking[]> = this.store.select(selectBookings);

  passengerName!: string;
  ticketCount!: number;
  ticketType!: string;
  flightName!: string;
  flightId!: string;
  start!: string;
  destination!: string;
  price!: number;
  ticketPrice!: number;

  constructor(
    private store: Store<AppState>,
    private flightService: FlightService
  ) {}

  ngOnInit(): void {
    this.loading = true;
    this.flightService
      .fetchBookings()
      .then((response) => {
        const data = response.items as Booking[];
        console.log(data);
        this.store.dispatch(fetchBookings({ bookings: data }));
        this.loading = false;
      })
      .catch((response) => {
        console.log(response);
        this.loading = false;
      });
  }

  deleteBooking() {
    this.loading = true;
    const id = this.currentBooking.id;
    this.flightService
      .deleteBooking(id)
      .then((response) => {
        console.log(response);
        this.store.dispatch(deleteBooking({ id }));
        this.loading = false;
      })
      .catch((error) => {
        console.log(error);
      });
  }

  updateBooking() {
    this.loading = true;
    const reqBody: UpdateBookingInput = {
      id: this.currentBooking.id,
      passengerName: this.passengerName,
      noOfTickets: this.ticketCount,
      totalAmount: this.price,
      ticketPrice: {
        type: this.ticketType as TicketType,
        price: this.ticketPrice,
      },
    };
    this.flightService
      .updateBooking(reqBody)
      .then((response) => {
        this.store.dispatch(
          updateBooking({ id: reqBody.id, booking: response })
        );
        this.loading = false;
      })
      .catch((error) => {
        console.log(error);
        this.loading = false;
      });
  }

  selectFlightTicketTypeAndCalculatePrice() {
    let price;

    if (this.ticketType) {
      console.log(this.ticketType, this.price);
      if (this.ticketType === 'ECONOMY_CLASS') price = this.ticketCount * 1000;
      else if (this.ticketType === 'BUSINESS_CLASS')
        price = this.ticketCount * 3000;
      else price = this.ticketCount * 5000;
      this.ticketPrice = price;

      this.price = price;
    }
  }

  selectBooking(booking: Booking) {
    this.currentBooking = booking;
    this.passengerName = this.currentBooking.passengerName;
    this.ticketCount = this.currentBooking.noOfTickets;
    this.ticketType = this.currentBooking.ticketPrice.type;
    this.flightName = this.currentBooking.flight?.name as string;
    this.flightId = this.currentBooking.flight?.flightId as string;
    this.start = this.currentBooking.flight?.startingLocation as string;
    this.destination = this.currentBooking.flight?.destination as string;
    this.price = this.currentBooking.totalAmount;
  }
}
