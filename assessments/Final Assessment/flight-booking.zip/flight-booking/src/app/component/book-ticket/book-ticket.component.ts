import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable, of, switchMap } from 'rxjs';
import { CreateBookingInput, Flight, User } from 'src/app/API.service';
import { FlightService } from 'src/app/service/flight/flight.service';
import { LocalStorageService } from 'src/app/service/local-storage/local-storage.service';
import { AppState } from 'src/app/store';
import { fetchFlights } from 'src/app/store/actions/flight.actions';
import { selectFlights } from 'src/app/store/selectors/flight.selectors';

@Component({
  selector: 'app-book-ticket',
  templateUrl: './book-ticket.component.html',
  styleUrls: ['./book-ticket.component.scss'],
})
export class BookTicketComponent implements OnInit {
  loading: boolean = true;
  isBooking: boolean = false;
  selectedFlight!: Flight;
  bookingForm: FormGroup;
  ticketPrice: number = 0;
  currentUserId!: string;
  user!: User;

  flights$: Observable<Flight[]> = this.store.select(selectFlights);

  constructor(
    private localStorageService: LocalStorageService,
    private flightService: FlightService,
    private store: Store<AppState>,
    private fb: FormBuilder,
    private router: Router
  ) {
    this.bookingForm = this.fb.group({
      passengerName: ['', Validators.required],
      ticketCount: [0, [Validators.max(40), Validators.min(1)]],
      ticketType: ['', Validators.required],
      flightName: ['', Validators.required],
      flightId: ['', Validators.required],
      start: ['', Validators.required],
      destination: ['', Validators.required],
      price: [0, Validators.required],
    });
  }

  ngOnInit(): void {
    this.loading = true;

    this.currentUserId =
      this.localStorageService.getCurrentUserIdFromLocalStorage() as string;

    this.flightService
      .fetchUserData()
      .then((response) => {
        this.user = response;
        this.bookingForm.controls['passengerName'].setValue(this.user.name);
      })
      .catch((error) => {
        console.log(error);
        this.loading = false;
      });

    this.flightService
      .fetchFlights()
      .then((response) => {
        console.log(response.items);
        const data = <Flight[]>response.items;
        this.store.dispatch(fetchFlights({ flights: data }));
        this.loading = false;
      })
      .catch((error) => {
        console.log(error);
        this.loading = false;
      });
  }

  bookFlight(id: string) {
    console.log(id);
    this.flights$.subscribe(
      (value) => {
        const flight = value.find((f) => f.id === id);
        if (!flight) return;

        this.bookingForm.controls['flightName'].setValue(flight.name);
        this.bookingForm.controls['flightId'].setValue(flight.flightId);
        this.bookingForm.controls['start'].setValue(flight.startingLocation);
        this.bookingForm.controls['destination'].setValue(flight.destination);
        this.selectedFlight = flight;
        this.isBooking = true;
      },
      (error) => {
        console.log(error);
      }
    );
  }

  createFlightBooking() {
    this.loading = true;
    const reqBody: CreateBookingInput = {
      noOfTickets: this.ticketCount,
      passengerName: this.passengerName,
      ticketPrice: {
        price: this.ticketPrice,
        type: this.ticketType,
      },
      totalAmount: this.totalAmount,
      flightId: this.selectedFlight.id,
      userId: this.currentUserId,
    };
    console.log(reqBody);

    this.flightService
      .addBooking(reqBody)
      .then((response) => {
        console.log(response);
        this.router.navigateByUrl('/view-details');
        this.loading = false;
      })
      .catch((error) => {
        console.log(error);
        this.loading = false;
      });
  }

  selectFlightByName() {
    this.flights$.subscribe(
      (value) => {
        const flight = value.find((f) => f.name === this.flightName);
        if (!flight) return;
        this.bookingForm.controls['flightId'].setValue(flight.flightId);
        this.bookingForm.controls['start'].setValue(flight.startingLocation);
        this.bookingForm.controls['destination'].setValue(flight.destination);
      },
      (error) => {
        console.log(error);
      }
    );
  }

  selectFlightTicketTypeAndCalculatePrice() {
    let price;

    if (this.ticketType) {
      if (this.ticketType === 'ECONOMY_CLASS') price = this.ticketCount * 1000;
      else if (this.ticketType === 'BUSINESS_CLASS')
        price = this.ticketCount * 3000;
      else price = this.ticketCount * 5000;
      this.ticketPrice = price;
      this.bookingForm.controls['ticketType'].setValue(this.ticketType);
      this.bookingForm.controls['price'].setValue(price);
    }
  }

  get passengerName() {
    return this.bookingForm.get('passengerName')?.value;
  }

  get ticketCount() {
    return this.bookingForm.get('ticketCount')?.value;
  }

  get flightName() {
    return this.bookingForm.get('flightName')?.value;
  }

  get flightId() {
    return this.bookingForm.get('flightId')?.value;
  }

  get start() {
    return this.bookingForm.get('start')?.value;
  }

  get destination() {
    return this.bookingForm.get('destination')?.value;
  }

  get ticketType() {
    return this.bookingForm.get('ticketType')?.value;
  }

  get totalAmount() {
    return this.bookingForm.get('price')?.value;
  }
}
