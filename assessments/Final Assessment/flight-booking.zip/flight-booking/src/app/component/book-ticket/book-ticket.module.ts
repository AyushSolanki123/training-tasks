import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BookTicketRoutingModule } from './book-ticket-routing.module';
import { BookTicketComponent } from './book-ticket.component';
import { LoadingModule } from 'src/app/loading/loading.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [BookTicketComponent],
  imports: [
    CommonModule,
    LoadingModule,
    BookTicketRoutingModule,
    FormsModule,
    ReactiveFormsModule,
  ],
})
export class BookTicketModule {}
