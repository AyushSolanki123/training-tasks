import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Auth } from 'aws-amplify';
import { APIService } from 'src/app/API.service';
import { LocalStorageService } from 'src/app/service/local-storage/local-storage.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent {
  loading: boolean = false;
  isPassword: boolean = true;
  email: string = '';
  password: string = '';

  constructor(
    private router: Router,
    private api: APIService,
    private localStorageService: LocalStorageService
  ) {}

  login() {
    this.loading = true;
    console.log(this.email, this.password);
    Auth.signIn(this.email, this.password)
      .then((response) => {
        console.log(response);
        return this.api.ListUsers({ email: { eq: this.email } });
      })
      .then((user) => {
        const id = user.items[0]?.id;

        if (!id) {
          this.router.navigateByUrl('/auth');
          return;
        }

        this.localStorageService.setCurrentUserIdInLocalStorage(id);

        this.loading = false;
        this.router.navigateByUrl('/home');
      })
      .catch((error) => {
        console.log(error);
        this.loading = false;
      });
  }
}
