import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Auth } from 'aws-amplify';
import { LocalStorageService } from 'src/app/service/local-storage/local-storage.service';

@Component({
  selector: 'app-confirm-user',
  templateUrl: './confirm-user.component.html',
  styleUrls: ['./confirm-user.component.scss'],
})
export class ConfirmUserComponent implements OnInit {
  loading: boolean = true;
  email: string = '';
  code: string = '';
  isConfirm: boolean = false;

  constructor(
    private router: Router,
    private localStorageService: LocalStorageService
  ) {}

  ngOnInit(): void {
    this.loading = true;
    const email =
      this.localStorageService.getCurrentUserEmailFromLocalStorage();
    if (!email) {
      this.router.navigateByUrl('/auth/register');
      return;
    }

    this.email = email;
    this.loading = false;
  }

  onSubmit() {
    this.loading = true;
    Auth.confirmSignUp(this.email, this.code)
      .then((response) => {
        console.log(response);
        this.loading = false;
        this.isConfirm = true;
      })
      .catch((error) => {
        console.log(error);
        this.loading = false;
      });
  }

  onResendCode() {
    Auth.resendSignUp(this.email)
      .then((response) => {
        console.log(response);
        console.log('Code sent SUccessfully');
      })
      .catch((error) => {
        console.log(error);
      });
  }
}
