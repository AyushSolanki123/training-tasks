import { createReducer, on } from '@ngrx/store';
import { Booking, Flight } from 'src/app/API.service';
import {
  bookFlight,
  deleteBooking,
  fetchBookings,
  fetchFlights,
  updateBooking,
} from '../actions/flight.actions';

export interface FlightState {
  flights: Flight[];
  bookings: Booking[];
}

const initialState: FlightState = {
  flights: [],
  bookings: [],
};

const _flightReducers = createReducer(
  initialState,
  on(fetchFlights, (state, { flights }) => {
    return {
      ...state,
      flights: flights,
    };
  }),
  on(fetchBookings, (state, { bookings }) => {
    return {
      ...state,
      bookings: bookings,
    };
  }),
  on(bookFlight, (state, { booking }) => {
    return {
      ...state,
      bookings: [...state.bookings, booking],
    };
  }),
  on(updateBooking, (state, { id, booking }) => {
    return {
      ...state,
      bookings: state.bookings.map((b) => (b.id == id ? booking : b)),
    };
  }),
  on(deleteBooking, (state, { id }) => {
    return {
      ...state,
      bookings: state.bookings.filter((b) => b.id != id),
    };
  })
);

export const flightsReducers = (state: any, action: any) => {
  return _flightReducers(state, action);
};
