import { createReducer, on } from '@ngrx/store';
import { loginUser, logout } from '../actions/auth.actions';
import { LocalStorageService } from 'src/app/service/local-storage/local-storage.service';

export interface AuthState {
  isLoggedIn: boolean;
}

const localStorageService = new LocalStorageService();

const initialState: AuthState = {
  isLoggedIn: false,
};

const _authReducers = createReducer(
  initialState,
  on(loginUser, (state) => {
    return {
      ...state,
      isLoggedIn: true,
    };
  }),
  on(logout, () => {
    localStorageService.removeCurrentUserEmailFromLocalStorage();
    localStorageService.removeCurrentUserIdFromLocalStorage();
    return initialState;
  })
);

export const authReducers = (state: any, action: any) => {
  return _authReducers(state, action);
};
