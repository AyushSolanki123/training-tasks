import { createFeatureSelector, createSelector } from '@ngrx/store';
import { AppState } from '..';
import { FlightState } from '../reducers/flight.reducers';

const selectFlightState = createFeatureSelector<AppState, FlightState>(
  'flightState'
);

export const selectFlights = createSelector(
  selectFlightState,
  (state: FlightState) => state.flights
);
export const selectBookings = createSelector(
  selectFlightState,
  (state: FlightState) => state.bookings
);
