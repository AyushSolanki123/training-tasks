import { createFeatureSelector, createSelector } from '@ngrx/store';
import { AppState } from '..';
import { AuthState } from '../reducers/auth.reducers';

const selectAuthState = createFeatureSelector<AppState, AuthState>('authState');

export const selectIsLoggedIn = createSelector(
  selectAuthState,
  (state: AuthState) => state.isLoggedIn
);
