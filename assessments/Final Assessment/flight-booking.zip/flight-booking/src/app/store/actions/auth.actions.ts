import { createAction } from '@ngrx/store';

export const LOGIN_USER = '[Auth Component] LOGIN_USER';
export const LOGOUT = '[Auth Component] LOGOUT';

export const loginUser = createAction(LOGIN_USER);
export const logout = createAction(LOGOUT);
