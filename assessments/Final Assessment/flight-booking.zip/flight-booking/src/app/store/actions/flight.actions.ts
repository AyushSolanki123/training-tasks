import { createAction, props } from '@ngrx/store';
import { Booking, Flight } from 'src/app/API.service';

export const FETCH_FLIGHTS = '[Book Flight Component] FETCH_FLIGHT';

export const BOOK_FLIGHTS = '[Book Flight Component] BOOK_FLIGHT';
export const FETCH_BOOKINGS = '[Book Flight Component] FETCH_BOOKINGS';
export const DELETE_BOOKING = '[Book FLight Component] DELETE_BOOKING';
export const UPDATE_BOOKING = '[Book Flight Component] UPDATE_BOOKING';

export const fetchFlights = createAction(
  FETCH_FLIGHTS,
  props<{ flights: Flight[] }>()
);

export const fetchBookings = createAction(
  FETCH_BOOKINGS,
  props<{ bookings: Booking[] }>()
);
export const bookFlight = createAction(
  BOOK_FLIGHTS,
  props<{ booking: Booking }>()
);
export const updateBooking = createAction(
  UPDATE_BOOKING,
  props<{ id: string; booking: Booking }>()
);
export const deleteBooking = createAction(
  DELETE_BOOKING,
  props<{ id: string }>()
);
