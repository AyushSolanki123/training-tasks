import { ActionReducerMap } from '@ngrx/store';
import { AuthState, authReducers } from './reducers/auth.reducers';
import { FlightState, flightsReducers } from './reducers/flight.reducers';

export interface AppState {
  authState: AuthState;
  flightState: FlightState;
}

export const reducers: ActionReducerMap<AppState> = {
  authState: authReducers,
  flightState: flightsReducers,
};
