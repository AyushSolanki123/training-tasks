import {
  ActivatedRouteSnapshot,
  CanActivate,
  CanActivateFn,
  Router,
  RouterStateSnapshot,
  UrlTree,
} from '@angular/router';
import { Store } from '@ngrx/store';
import { AppState } from './store';
import { Observable } from 'rxjs';
import { selectIsLoggedIn } from './store/selectors/auth.selectors';
import { Injectable } from '@angular/core';
import { LocalStorageService } from './service/local-storage/local-storage.service';

@Injectable({
  providedIn: 'root',
})
export class AuthGuard implements CanActivate {
  isLoggedIn!: boolean;

  constructor(
    private localStorageService: LocalStorageService,
    private router: Router
  ) {}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): boolean {
    const userId = this.localStorageService.getCurrentUserIdFromLocalStorage();
    if (userId) {
      this.isLoggedIn = true;
    } else {
      this.isLoggedIn = false;
    }
    if (this.isLoggedIn) {
      return this.isLoggedIn;
    } else {
      this.router.navigateByUrl('/auth/login');
      return false;
    }
  }
}
