import { Injectable } from '@angular/core';

const CURRENT_USER_EMAIL = 'CURRENT_USER_EMAIL';
const CURRENT_USER_ID = 'CURRENT_USER_ID';

@Injectable({
  providedIn: 'root',
})
export class LocalStorageService {
  constructor() {}

  setCurrentUserEmailInLocalStorage(email: string) {
    localStorage.setItem(CURRENT_USER_EMAIL, email);
  }

  getCurrentUserEmailFromLocalStorage() {
    return localStorage.getItem(CURRENT_USER_EMAIL);
  }

  removeCurrentUserEmailFromLocalStorage() {
    localStorage.removeItem(CURRENT_USER_EMAIL);
  }

  setCurrentUserIdInLocalStorage(id: string) {
    localStorage.setItem(CURRENT_USER_ID, id);
  }

  getCurrentUserIdFromLocalStorage() {
    return localStorage.getItem(CURRENT_USER_ID);
  }

  removeCurrentUserIdFromLocalStorage() {
    localStorage.removeItem(CURRENT_USER_ID);
  }
}
