import { Injectable } from '@angular/core';
import {
  APIService,
  CreateBookingInput,
  UpdateBookingInput,
} from 'src/app/API.service';
import { LocalStorageService } from '../local-storage/local-storage.service';

@Injectable({
  providedIn: 'root',
})
export class FlightService {
  constructor(
    private api: APIService,
    private localStorageService: LocalStorageService
  ) {}

  fetchFlights() {
    return this.api.ListFlights();
  }

  fetchBookings() {
    return this.api.ListBookings();
  }

  fetchUserData() {
    const userId =
      this.localStorageService.getCurrentUserIdFromLocalStorage() as string;
    return this.api.GetUser(userId);
  }

  addBooking(reqBody: CreateBookingInput) {
    return this.api.CreateBooking(reqBody);
  }

  updateBooking(reqBody: UpdateBookingInput) {
    return this.api.UpdateBooking(reqBody);
  }

  deleteBooking(id: string) {
    return this.api.DeleteBooking({ id });
  }
}
