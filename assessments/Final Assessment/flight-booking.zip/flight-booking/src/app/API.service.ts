/* tslint:disable */
/* eslint-disable */
//  This file was automatically generated and should not be edited.
import { Injectable } from "@angular/core";
import API, { graphqlOperation, GraphQLResult } from "@aws-amplify/api-graphql";
import { Observable } from "zen-observable-ts";

export interface SubscriptionResponse<T> {
  value: GraphQLResult<T>;
}

export type __SubscriptionContainer = {
  onCreateFlight: OnCreateFlightSubscription;
  onUpdateFlight: OnUpdateFlightSubscription;
  onDeleteFlight: OnDeleteFlightSubscription;
  onCreateBooking: OnCreateBookingSubscription;
  onUpdateBooking: OnUpdateBookingSubscription;
  onDeleteBooking: OnDeleteBookingSubscription;
  onCreateUser: OnCreateUserSubscription;
  onUpdateUser: OnUpdateUserSubscription;
  onDeleteUser: OnDeleteUserSubscription;
};

export type CreateFlightInput = {
  id?: string | null;
  flightId: string;
  name: string;
  startingLocation: Location;
  destination: Location;
};

export enum Location {
  CALIFORNIA = "CALIFORNIA",
  DUBLIN = "DUBLIN",
  NEW_DELHI = "NEW_DELHI",
  TOKYO = "TOKYO",
  KYOTO = "KYOTO",
  MUMBAI = "MUMBAI",
  KOLKATA = "KOLKATA",
  LONDON = "LONDON",
  PRAGUE = "PRAGUE",
  NEW_YORK = "NEW_YORK",
  SYDNEY = "SYDNEY"
}

export type ModelFlightConditionInput = {
  flightId?: ModelStringInput | null;
  name?: ModelStringInput | null;
  startingLocation?: ModelLocationInput | null;
  destination?: ModelLocationInput | null;
  and?: Array<ModelFlightConditionInput | null> | null;
  or?: Array<ModelFlightConditionInput | null> | null;
  not?: ModelFlightConditionInput | null;
};

export type ModelStringInput = {
  ne?: string | null;
  eq?: string | null;
  le?: string | null;
  lt?: string | null;
  ge?: string | null;
  gt?: string | null;
  contains?: string | null;
  notContains?: string | null;
  between?: Array<string | null> | null;
  beginsWith?: string | null;
  attributeExists?: boolean | null;
  attributeType?: ModelAttributeTypes | null;
  size?: ModelSizeInput | null;
};

export enum ModelAttributeTypes {
  binary = "binary",
  binarySet = "binarySet",
  bool = "bool",
  list = "list",
  map = "map",
  number = "number",
  numberSet = "numberSet",
  string = "string",
  stringSet = "stringSet",
  _null = "_null"
}

export type ModelSizeInput = {
  ne?: number | null;
  eq?: number | null;
  le?: number | null;
  lt?: number | null;
  ge?: number | null;
  gt?: number | null;
  between?: Array<number | null> | null;
};

export type ModelLocationInput = {
  eq?: Location | null;
  ne?: Location | null;
};

export type Flight = {
  __typename: "Flight";
  id: string;
  flightId: string;
  name: string;
  startingLocation: Location;
  destination: Location;
  createdAt: string;
  updatedAt: string;
};

export type UpdateFlightInput = {
  id: string;
  flightId?: string | null;
  name?: string | null;
  startingLocation?: Location | null;
  destination?: Location | null;
};

export type DeleteFlightInput = {
  id: string;
};

export type CreateBookingInput = {
  id?: string | null;
  flightId?: string | null;
  userId?: string | null;
  passengerName: string;
  noOfTickets: number;
  ticketPrice: TicketPriceInput;
  totalAmount: number;
};

export type TicketPriceInput = {
  type: TicketType;
  price: number;
};

export enum TicketType {
  ECONOMY_CLASS = "ECONOMY_CLASS",
  BUSINESS_CLASS = "BUSINESS_CLASS",
  FIRST_CLASS = "FIRST_CLASS"
}

export type ModelBookingConditionInput = {
  flightId?: ModelIDInput | null;
  userId?: ModelIDInput | null;
  passengerName?: ModelStringInput | null;
  noOfTickets?: ModelIntInput | null;
  totalAmount?: ModelFloatInput | null;
  and?: Array<ModelBookingConditionInput | null> | null;
  or?: Array<ModelBookingConditionInput | null> | null;
  not?: ModelBookingConditionInput | null;
};

export type ModelIDInput = {
  ne?: string | null;
  eq?: string | null;
  le?: string | null;
  lt?: string | null;
  ge?: string | null;
  gt?: string | null;
  contains?: string | null;
  notContains?: string | null;
  between?: Array<string | null> | null;
  beginsWith?: string | null;
  attributeExists?: boolean | null;
  attributeType?: ModelAttributeTypes | null;
  size?: ModelSizeInput | null;
};

export type ModelIntInput = {
  ne?: number | null;
  eq?: number | null;
  le?: number | null;
  lt?: number | null;
  ge?: number | null;
  gt?: number | null;
  between?: Array<number | null> | null;
  attributeExists?: boolean | null;
  attributeType?: ModelAttributeTypes | null;
};

export type ModelFloatInput = {
  ne?: number | null;
  eq?: number | null;
  le?: number | null;
  lt?: number | null;
  ge?: number | null;
  gt?: number | null;
  between?: Array<number | null> | null;
  attributeExists?: boolean | null;
  attributeType?: ModelAttributeTypes | null;
};

export type Booking = {
  __typename: "Booking";
  id: string;
  flightId?: string | null;
  flight?: Flight | null;
  userId?: string | null;
  user?: User | null;
  passengerName: string;
  noOfTickets: number;
  ticketPrice: TicketPrice;
  totalAmount: number;
  createdAt: string;
  updatedAt: string;
};

export type User = {
  __typename: "User";
  id: string;
  name: string;
  email: string;
  password: string;
  createdAt: string;
  updatedAt: string;
};

export type TicketPrice = {
  __typename: "TicketPrice";
  type: TicketType;
  price: number;
};

export type UpdateBookingInput = {
  id: string;
  flightId?: string | null;
  userId?: string | null;
  passengerName?: string | null;
  noOfTickets?: number | null;
  ticketPrice?: TicketPriceInput | null;
  totalAmount?: number | null;
};

export type DeleteBookingInput = {
  id: string;
};

export type CreateUserInput = {
  id?: string | null;
  name: string;
  email: string;
  password: string;
};

export type ModelUserConditionInput = {
  name?: ModelStringInput | null;
  email?: ModelStringInput | null;
  password?: ModelStringInput | null;
  and?: Array<ModelUserConditionInput | null> | null;
  or?: Array<ModelUserConditionInput | null> | null;
  not?: ModelUserConditionInput | null;
};

export type UpdateUserInput = {
  id: string;
  name?: string | null;
  email?: string | null;
  password?: string | null;
};

export type DeleteUserInput = {
  id: string;
};

export type SearchableFlightFilterInput = {
  id?: SearchableIDFilterInput | null;
  flightId?: SearchableStringFilterInput | null;
  name?: SearchableStringFilterInput | null;
  createdAt?: SearchableStringFilterInput | null;
  updatedAt?: SearchableStringFilterInput | null;
  startingLocation?: SearchableStringFilterInput | null;
  destination?: SearchableStringFilterInput | null;
  and?: Array<SearchableFlightFilterInput | null> | null;
  or?: Array<SearchableFlightFilterInput | null> | null;
  not?: SearchableFlightFilterInput | null;
};

export type SearchableIDFilterInput = {
  ne?: string | null;
  gt?: string | null;
  lt?: string | null;
  gte?: string | null;
  lte?: string | null;
  eq?: string | null;
  match?: string | null;
  matchPhrase?: string | null;
  matchPhrasePrefix?: string | null;
  multiMatch?: string | null;
  exists?: boolean | null;
  wildcard?: string | null;
  regexp?: string | null;
  range?: Array<string | null> | null;
};

export type SearchableStringFilterInput = {
  ne?: string | null;
  gt?: string | null;
  lt?: string | null;
  gte?: string | null;
  lte?: string | null;
  eq?: string | null;
  match?: string | null;
  matchPhrase?: string | null;
  matchPhrasePrefix?: string | null;
  multiMatch?: string | null;
  exists?: boolean | null;
  wildcard?: string | null;
  regexp?: string | null;
  range?: Array<string | null> | null;
};

export type SearchableFlightSortInput = {
  field?: SearchableFlightSortableFields | null;
  direction?: SearchableSortDirection | null;
};

export enum SearchableFlightSortableFields {
  id = "id",
  flightId = "flightId",
  name = "name",
  createdAt = "createdAt",
  updatedAt = "updatedAt"
}

export enum SearchableSortDirection {
  asc = "asc",
  desc = "desc"
}

export type SearchableFlightAggregationInput = {
  name: string;
  type: SearchableAggregateType;
  field: SearchableFlightAggregateField;
};

export enum SearchableAggregateType {
  terms = "terms",
  avg = "avg",
  min = "min",
  max = "max",
  sum = "sum"
}

export enum SearchableFlightAggregateField {
  id = "id",
  flightId = "flightId",
  name = "name",
  startingLocation = "startingLocation",
  destination = "destination",
  createdAt = "createdAt",
  updatedAt = "updatedAt"
}

export type SearchableFlightConnection = {
  __typename: "SearchableFlightConnection";
  items: Array<Flight | null>;
  nextToken?: string | null;
  total?: number | null;
  aggregateItems: Array<SearchableAggregateResult | null>;
};

export type SearchableAggregateResult = {
  __typename: "SearchableAggregateResult";
  name: string;
  result?: SearchableAggregateGenericResult | null;
};

export type SearchableAggregateGenericResult =
  | SearchableAggregateScalarResult
  | SearchableAggregateBucketResult;

export type SearchableAggregateScalarResult = {
  __typename: "SearchableAggregateScalarResult";
  value: number;
};

export type SearchableAggregateBucketResult = {
  __typename: "SearchableAggregateBucketResult";
  buckets?: Array<SearchableAggregateBucketResultItem | null> | null;
};

export type SearchableAggregateBucketResultItem = {
  __typename: "SearchableAggregateBucketResultItem";
  key: string;
  doc_count: number;
};

export type SearchableBookingFilterInput = {
  id?: SearchableIDFilterInput | null;
  flightId?: SearchableIDFilterInput | null;
  userId?: SearchableIDFilterInput | null;
  passengerName?: SearchableStringFilterInput | null;
  noOfTickets?: SearchableIntFilterInput | null;
  totalAmount?: SearchableFloatFilterInput | null;
  createdAt?: SearchableStringFilterInput | null;
  updatedAt?: SearchableStringFilterInput | null;
  and?: Array<SearchableBookingFilterInput | null> | null;
  or?: Array<SearchableBookingFilterInput | null> | null;
  not?: SearchableBookingFilterInput | null;
};

export type SearchableIntFilterInput = {
  ne?: number | null;
  gt?: number | null;
  lt?: number | null;
  gte?: number | null;
  lte?: number | null;
  eq?: number | null;
  range?: Array<number | null> | null;
};

export type SearchableFloatFilterInput = {
  ne?: number | null;
  gt?: number | null;
  lt?: number | null;
  gte?: number | null;
  lte?: number | null;
  eq?: number | null;
  range?: Array<number | null> | null;
};

export type SearchableBookingSortInput = {
  field?: SearchableBookingSortableFields | null;
  direction?: SearchableSortDirection | null;
};

export enum SearchableBookingSortableFields {
  id = "id",
  flightId = "flightId",
  userId = "userId",
  passengerName = "passengerName",
  noOfTickets = "noOfTickets",
  totalAmount = "totalAmount",
  createdAt = "createdAt",
  updatedAt = "updatedAt"
}

export type SearchableBookingAggregationInput = {
  name: string;
  type: SearchableAggregateType;
  field: SearchableBookingAggregateField;
};

export enum SearchableBookingAggregateField {
  id = "id",
  flightId = "flightId",
  userId = "userId",
  passengerName = "passengerName",
  noOfTickets = "noOfTickets",
  totalAmount = "totalAmount",
  createdAt = "createdAt",
  updatedAt = "updatedAt"
}

export type SearchableBookingConnection = {
  __typename: "SearchableBookingConnection";
  items: Array<Booking | null>;
  nextToken?: string | null;
  total?: number | null;
  aggregateItems: Array<SearchableAggregateResult | null>;
};

export type ModelFlightFilterInput = {
  id?: ModelIDInput | null;
  flightId?: ModelStringInput | null;
  name?: ModelStringInput | null;
  startingLocation?: ModelLocationInput | null;
  destination?: ModelLocationInput | null;
  and?: Array<ModelFlightFilterInput | null> | null;
  or?: Array<ModelFlightFilterInput | null> | null;
  not?: ModelFlightFilterInput | null;
};

export type ModelFlightConnection = {
  __typename: "ModelFlightConnection";
  items: Array<Flight | null>;
  nextToken?: string | null;
};

export type ModelBookingFilterInput = {
  id?: ModelIDInput | null;
  flightId?: ModelIDInput | null;
  userId?: ModelIDInput | null;
  passengerName?: ModelStringInput | null;
  noOfTickets?: ModelIntInput | null;
  totalAmount?: ModelFloatInput | null;
  and?: Array<ModelBookingFilterInput | null> | null;
  or?: Array<ModelBookingFilterInput | null> | null;
  not?: ModelBookingFilterInput | null;
};

export type ModelBookingConnection = {
  __typename: "ModelBookingConnection";
  items: Array<Booking | null>;
  nextToken?: string | null;
};

export type ModelUserFilterInput = {
  id?: ModelIDInput | null;
  name?: ModelStringInput | null;
  email?: ModelStringInput | null;
  password?: ModelStringInput | null;
  and?: Array<ModelUserFilterInput | null> | null;
  or?: Array<ModelUserFilterInput | null> | null;
  not?: ModelUserFilterInput | null;
};

export type ModelUserConnection = {
  __typename: "ModelUserConnection";
  items: Array<User | null>;
  nextToken?: string | null;
};

export enum ModelSortDirection {
  ASC = "ASC",
  DESC = "DESC"
}

export type ModelSubscriptionFlightFilterInput = {
  id?: ModelSubscriptionIDInput | null;
  flightId?: ModelSubscriptionStringInput | null;
  name?: ModelSubscriptionStringInput | null;
  startingLocation?: ModelSubscriptionStringInput | null;
  destination?: ModelSubscriptionStringInput | null;
  and?: Array<ModelSubscriptionFlightFilterInput | null> | null;
  or?: Array<ModelSubscriptionFlightFilterInput | null> | null;
};

export type ModelSubscriptionIDInput = {
  ne?: string | null;
  eq?: string | null;
  le?: string | null;
  lt?: string | null;
  ge?: string | null;
  gt?: string | null;
  contains?: string | null;
  notContains?: string | null;
  between?: Array<string | null> | null;
  beginsWith?: string | null;
  in?: Array<string | null> | null;
  notIn?: Array<string | null> | null;
};

export type ModelSubscriptionStringInput = {
  ne?: string | null;
  eq?: string | null;
  le?: string | null;
  lt?: string | null;
  ge?: string | null;
  gt?: string | null;
  contains?: string | null;
  notContains?: string | null;
  between?: Array<string | null> | null;
  beginsWith?: string | null;
  in?: Array<string | null> | null;
  notIn?: Array<string | null> | null;
};

export type ModelSubscriptionBookingFilterInput = {
  id?: ModelSubscriptionIDInput | null;
  flightId?: ModelSubscriptionIDInput | null;
  userId?: ModelSubscriptionIDInput | null;
  passengerName?: ModelSubscriptionStringInput | null;
  noOfTickets?: ModelSubscriptionIntInput | null;
  totalAmount?: ModelSubscriptionFloatInput | null;
  and?: Array<ModelSubscriptionBookingFilterInput | null> | null;
  or?: Array<ModelSubscriptionBookingFilterInput | null> | null;
};

export type ModelSubscriptionIntInput = {
  ne?: number | null;
  eq?: number | null;
  le?: number | null;
  lt?: number | null;
  ge?: number | null;
  gt?: number | null;
  between?: Array<number | null> | null;
  in?: Array<number | null> | null;
  notIn?: Array<number | null> | null;
};

export type ModelSubscriptionFloatInput = {
  ne?: number | null;
  eq?: number | null;
  le?: number | null;
  lt?: number | null;
  ge?: number | null;
  gt?: number | null;
  between?: Array<number | null> | null;
  in?: Array<number | null> | null;
  notIn?: Array<number | null> | null;
};

export type ModelSubscriptionUserFilterInput = {
  id?: ModelSubscriptionIDInput | null;
  name?: ModelSubscriptionStringInput | null;
  email?: ModelSubscriptionStringInput | null;
  password?: ModelSubscriptionStringInput | null;
  and?: Array<ModelSubscriptionUserFilterInput | null> | null;
  or?: Array<ModelSubscriptionUserFilterInput | null> | null;
};

export type CreateFlightMutation = {
  __typename: "Flight";
  id: string;
  flightId: string;
  name: string;
  startingLocation: Location;
  destination: Location;
  createdAt: string;
  updatedAt: string;
};

export type UpdateFlightMutation = {
  __typename: "Flight";
  id: string;
  flightId: string;
  name: string;
  startingLocation: Location;
  destination: Location;
  createdAt: string;
  updatedAt: string;
};

export type DeleteFlightMutation = {
  __typename: "Flight";
  id: string;
  flightId: string;
  name: string;
  startingLocation: Location;
  destination: Location;
  createdAt: string;
  updatedAt: string;
};

export type CreateBookingMutation = {
  __typename: "Booking";
  id: string;
  flightId?: string | null;
  flight?: {
    __typename: "Flight";
    id: string;
    flightId: string;
    name: string;
    startingLocation: Location;
    destination: Location;
    createdAt: string;
    updatedAt: string;
  } | null;
  userId?: string | null;
  user?: {
    __typename: "User";
    id: string;
    name: string;
    email: string;
    password: string;
    createdAt: string;
    updatedAt: string;
  } | null;
  passengerName: string;
  noOfTickets: number;
  ticketPrice: {
    __typename: "TicketPrice";
    type: TicketType;
    price: number;
  };
  totalAmount: number;
  createdAt: string;
  updatedAt: string;
};

export type UpdateBookingMutation = {
  __typename: "Booking";
  id: string;
  flightId?: string | null;
  flight?: {
    __typename: "Flight";
    id: string;
    flightId: string;
    name: string;
    startingLocation: Location;
    destination: Location;
    createdAt: string;
    updatedAt: string;
  } | null;
  userId?: string | null;
  user?: {
    __typename: "User";
    id: string;
    name: string;
    email: string;
    password: string;
    createdAt: string;
    updatedAt: string;
  } | null;
  passengerName: string;
  noOfTickets: number;
  ticketPrice: {
    __typename: "TicketPrice";
    type: TicketType;
    price: number;
  };
  totalAmount: number;
  createdAt: string;
  updatedAt: string;
};

export type DeleteBookingMutation = {
  __typename: "Booking";
  id: string;
  flightId?: string | null;
  flight?: {
    __typename: "Flight";
    id: string;
    flightId: string;
    name: string;
    startingLocation: Location;
    destination: Location;
    createdAt: string;
    updatedAt: string;
  } | null;
  userId?: string | null;
  user?: {
    __typename: "User";
    id: string;
    name: string;
    email: string;
    password: string;
    createdAt: string;
    updatedAt: string;
  } | null;
  passengerName: string;
  noOfTickets: number;
  ticketPrice: {
    __typename: "TicketPrice";
    type: TicketType;
    price: number;
  };
  totalAmount: number;
  createdAt: string;
  updatedAt: string;
};

export type CreateUserMutation = {
  __typename: "User";
  id: string;
  name: string;
  email: string;
  password: string;
  createdAt: string;
  updatedAt: string;
};

export type UpdateUserMutation = {
  __typename: "User";
  id: string;
  name: string;
  email: string;
  password: string;
  createdAt: string;
  updatedAt: string;
};

export type DeleteUserMutation = {
  __typename: "User";
  id: string;
  name: string;
  email: string;
  password: string;
  createdAt: string;
  updatedAt: string;
};

export type SearchFlightsQuery = {
  __typename: "SearchableFlightConnection";
  items: Array<{
    __typename: "Flight";
    id: string;
    flightId: string;
    name: string;
    startingLocation: Location;
    destination: Location;
    createdAt: string;
    updatedAt: string;
  } | null>;
  nextToken?: string | null;
  total?: number | null;
  aggregateItems: Array<{
    __typename: "SearchableAggregateResult";
    name: string;
    result:
      | (
          | {
              __typename: "SearchableAggregateScalarResult";
              value: number;
            }
          | {
              __typename: "SearchableAggregateBucketResult";
              buckets?: Array<{
                __typename: string;
                key: string;
                doc_count: number;
              } | null> | null;
            }
        )
      | null;
  } | null>;
};

export type SearchBookingsQuery = {
  __typename: "SearchableBookingConnection";
  items: Array<{
    __typename: "Booking";
    id: string;
    flightId?: string | null;
    flight?: {
      __typename: "Flight";
      id: string;
      flightId: string;
      name: string;
      startingLocation: Location;
      destination: Location;
      createdAt: string;
      updatedAt: string;
    } | null;
    userId?: string | null;
    user?: {
      __typename: "User";
      id: string;
      name: string;
      email: string;
      password: string;
      createdAt: string;
      updatedAt: string;
    } | null;
    passengerName: string;
    noOfTickets: number;
    ticketPrice: {
      __typename: "TicketPrice";
      type: TicketType;
      price: number;
    };
    totalAmount: number;
    createdAt: string;
    updatedAt: string;
  } | null>;
  nextToken?: string | null;
  total?: number | null;
  aggregateItems: Array<{
    __typename: "SearchableAggregateResult";
    name: string;
    result:
      | (
          | {
              __typename: "SearchableAggregateScalarResult";
              value: number;
            }
          | {
              __typename: "SearchableAggregateBucketResult";
              buckets?: Array<{
                __typename: string;
                key: string;
                doc_count: number;
              } | null> | null;
            }
        )
      | null;
  } | null>;
};

export type GetFlightQuery = {
  __typename: "Flight";
  id: string;
  flightId: string;
  name: string;
  startingLocation: Location;
  destination: Location;
  createdAt: string;
  updatedAt: string;
};

export type ListFlightsQuery = {
  __typename: "ModelFlightConnection";
  items: Array<{
    __typename: "Flight";
    id: string;
    flightId: string;
    name: string;
    startingLocation: Location;
    destination: Location;
    createdAt: string;
    updatedAt: string;
  } | null>;
  nextToken?: string | null;
};

export type GetBookingQuery = {
  __typename: "Booking";
  id: string;
  flightId?: string | null;
  flight?: {
    __typename: "Flight";
    id: string;
    flightId: string;
    name: string;
    startingLocation: Location;
    destination: Location;
    createdAt: string;
    updatedAt: string;
  } | null;
  userId?: string | null;
  user?: {
    __typename: "User";
    id: string;
    name: string;
    email: string;
    password: string;
    createdAt: string;
    updatedAt: string;
  } | null;
  passengerName: string;
  noOfTickets: number;
  ticketPrice: {
    __typename: "TicketPrice";
    type: TicketType;
    price: number;
  };
  totalAmount: number;
  createdAt: string;
  updatedAt: string;
};

export type ListBookingsQuery = {
  __typename: "ModelBookingConnection";
  items: Array<{
    __typename: "Booking";
    id: string;
    flightId?: string | null;
    flight?: {
      __typename: "Flight";
      id: string;
      flightId: string;
      name: string;
      startingLocation: Location;
      destination: Location;
      createdAt: string;
      updatedAt: string;
    } | null;
    userId?: string | null;
    user?: {
      __typename: "User";
      id: string;
      name: string;
      email: string;
      password: string;
      createdAt: string;
      updatedAt: string;
    } | null;
    passengerName: string;
    noOfTickets: number;
    ticketPrice: {
      __typename: "TicketPrice";
      type: TicketType;
      price: number;
    };
    totalAmount: number;
    createdAt: string;
    updatedAt: string;
  } | null>;
  nextToken?: string | null;
};

export type GetUserQuery = {
  __typename: "User";
  id: string;
  name: string;
  email: string;
  password: string;
  createdAt: string;
  updatedAt: string;
};

export type ListUsersQuery = {
  __typename: "ModelUserConnection";
  items: Array<{
    __typename: "User";
    id: string;
    name: string;
    email: string;
    password: string;
    createdAt: string;
    updatedAt: string;
  } | null>;
  nextToken?: string | null;
};

export type FlightByFlightIdQuery = {
  __typename: "ModelFlightConnection";
  items: Array<{
    __typename: "Flight";
    id: string;
    flightId: string;
    name: string;
    startingLocation: Location;
    destination: Location;
    createdAt: string;
    updatedAt: string;
  } | null>;
  nextToken?: string | null;
};

export type OnCreateFlightSubscription = {
  __typename: "Flight";
  id: string;
  flightId: string;
  name: string;
  startingLocation: Location;
  destination: Location;
  createdAt: string;
  updatedAt: string;
};

export type OnUpdateFlightSubscription = {
  __typename: "Flight";
  id: string;
  flightId: string;
  name: string;
  startingLocation: Location;
  destination: Location;
  createdAt: string;
  updatedAt: string;
};

export type OnDeleteFlightSubscription = {
  __typename: "Flight";
  id: string;
  flightId: string;
  name: string;
  startingLocation: Location;
  destination: Location;
  createdAt: string;
  updatedAt: string;
};

export type OnCreateBookingSubscription = {
  __typename: "Booking";
  id: string;
  flightId?: string | null;
  flight?: {
    __typename: "Flight";
    id: string;
    flightId: string;
    name: string;
    startingLocation: Location;
    destination: Location;
    createdAt: string;
    updatedAt: string;
  } | null;
  userId?: string | null;
  user?: {
    __typename: "User";
    id: string;
    name: string;
    email: string;
    password: string;
    createdAt: string;
    updatedAt: string;
  } | null;
  passengerName: string;
  noOfTickets: number;
  ticketPrice: {
    __typename: "TicketPrice";
    type: TicketType;
    price: number;
  };
  totalAmount: number;
  createdAt: string;
  updatedAt: string;
};

export type OnUpdateBookingSubscription = {
  __typename: "Booking";
  id: string;
  flightId?: string | null;
  flight?: {
    __typename: "Flight";
    id: string;
    flightId: string;
    name: string;
    startingLocation: Location;
    destination: Location;
    createdAt: string;
    updatedAt: string;
  } | null;
  userId?: string | null;
  user?: {
    __typename: "User";
    id: string;
    name: string;
    email: string;
    password: string;
    createdAt: string;
    updatedAt: string;
  } | null;
  passengerName: string;
  noOfTickets: number;
  ticketPrice: {
    __typename: "TicketPrice";
    type: TicketType;
    price: number;
  };
  totalAmount: number;
  createdAt: string;
  updatedAt: string;
};

export type OnDeleteBookingSubscription = {
  __typename: "Booking";
  id: string;
  flightId?: string | null;
  flight?: {
    __typename: "Flight";
    id: string;
    flightId: string;
    name: string;
    startingLocation: Location;
    destination: Location;
    createdAt: string;
    updatedAt: string;
  } | null;
  userId?: string | null;
  user?: {
    __typename: "User";
    id: string;
    name: string;
    email: string;
    password: string;
    createdAt: string;
    updatedAt: string;
  } | null;
  passengerName: string;
  noOfTickets: number;
  ticketPrice: {
    __typename: "TicketPrice";
    type: TicketType;
    price: number;
  };
  totalAmount: number;
  createdAt: string;
  updatedAt: string;
};

export type OnCreateUserSubscription = {
  __typename: "User";
  id: string;
  name: string;
  email: string;
  password: string;
  createdAt: string;
  updatedAt: string;
};

export type OnUpdateUserSubscription = {
  __typename: "User";
  id: string;
  name: string;
  email: string;
  password: string;
  createdAt: string;
  updatedAt: string;
};

export type OnDeleteUserSubscription = {
  __typename: "User";
  id: string;
  name: string;
  email: string;
  password: string;
  createdAt: string;
  updatedAt: string;
};

@Injectable({
  providedIn: "root"
})
export class APIService {
  async CreateFlight(
    input: CreateFlightInput,
    condition?: ModelFlightConditionInput
  ): Promise<CreateFlightMutation> {
    const statement = `mutation CreateFlight($input: CreateFlightInput!, $condition: ModelFlightConditionInput) {
        createFlight(input: $input, condition: $condition) {
          __typename
          id
          flightId
          name
          startingLocation
          destination
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <CreateFlightMutation>response.data.createFlight;
  }
  async UpdateFlight(
    input: UpdateFlightInput,
    condition?: ModelFlightConditionInput
  ): Promise<UpdateFlightMutation> {
    const statement = `mutation UpdateFlight($input: UpdateFlightInput!, $condition: ModelFlightConditionInput) {
        updateFlight(input: $input, condition: $condition) {
          __typename
          id
          flightId
          name
          startingLocation
          destination
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <UpdateFlightMutation>response.data.updateFlight;
  }
  async DeleteFlight(
    input: DeleteFlightInput,
    condition?: ModelFlightConditionInput
  ): Promise<DeleteFlightMutation> {
    const statement = `mutation DeleteFlight($input: DeleteFlightInput!, $condition: ModelFlightConditionInput) {
        deleteFlight(input: $input, condition: $condition) {
          __typename
          id
          flightId
          name
          startingLocation
          destination
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <DeleteFlightMutation>response.data.deleteFlight;
  }
  async CreateBooking(
    input: CreateBookingInput,
    condition?: ModelBookingConditionInput
  ): Promise<CreateBookingMutation> {
    const statement = `mutation CreateBooking($input: CreateBookingInput!, $condition: ModelBookingConditionInput) {
        createBooking(input: $input, condition: $condition) {
          __typename
          id
          flightId
          flight {
            __typename
            id
            flightId
            name
            startingLocation
            destination
            createdAt
            updatedAt
          }
          userId
          user {
            __typename
            id
            name
            email
            password
            createdAt
            updatedAt
          }
          passengerName
          noOfTickets
          ticketPrice {
            __typename
            type
            price
          }
          totalAmount
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <CreateBookingMutation>response.data.createBooking;
  }
  async UpdateBooking(
    input: UpdateBookingInput,
    condition?: ModelBookingConditionInput
  ): Promise<UpdateBookingMutation> {
    const statement = `mutation UpdateBooking($input: UpdateBookingInput!, $condition: ModelBookingConditionInput) {
        updateBooking(input: $input, condition: $condition) {
          __typename
          id
          flightId
          flight {
            __typename
            id
            flightId
            name
            startingLocation
            destination
            createdAt
            updatedAt
          }
          userId
          user {
            __typename
            id
            name
            email
            password
            createdAt
            updatedAt
          }
          passengerName
          noOfTickets
          ticketPrice {
            __typename
            type
            price
          }
          totalAmount
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <UpdateBookingMutation>response.data.updateBooking;
  }
  async DeleteBooking(
    input: DeleteBookingInput,
    condition?: ModelBookingConditionInput
  ): Promise<DeleteBookingMutation> {
    const statement = `mutation DeleteBooking($input: DeleteBookingInput!, $condition: ModelBookingConditionInput) {
        deleteBooking(input: $input, condition: $condition) {
          __typename
          id
          flightId
          flight {
            __typename
            id
            flightId
            name
            startingLocation
            destination
            createdAt
            updatedAt
          }
          userId
          user {
            __typename
            id
            name
            email
            password
            createdAt
            updatedAt
          }
          passengerName
          noOfTickets
          ticketPrice {
            __typename
            type
            price
          }
          totalAmount
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <DeleteBookingMutation>response.data.deleteBooking;
  }
  async CreateUser(
    input: CreateUserInput,
    condition?: ModelUserConditionInput
  ): Promise<CreateUserMutation> {
    const statement = `mutation CreateUser($input: CreateUserInput!, $condition: ModelUserConditionInput) {
        createUser(input: $input, condition: $condition) {
          __typename
          id
          name
          email
          password
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <CreateUserMutation>response.data.createUser;
  }
  async UpdateUser(
    input: UpdateUserInput,
    condition?: ModelUserConditionInput
  ): Promise<UpdateUserMutation> {
    const statement = `mutation UpdateUser($input: UpdateUserInput!, $condition: ModelUserConditionInput) {
        updateUser(input: $input, condition: $condition) {
          __typename
          id
          name
          email
          password
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <UpdateUserMutation>response.data.updateUser;
  }
  async DeleteUser(
    input: DeleteUserInput,
    condition?: ModelUserConditionInput
  ): Promise<DeleteUserMutation> {
    const statement = `mutation DeleteUser($input: DeleteUserInput!, $condition: ModelUserConditionInput) {
        deleteUser(input: $input, condition: $condition) {
          __typename
          id
          name
          email
          password
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <DeleteUserMutation>response.data.deleteUser;
  }
  async SearchFlights(
    filter?: SearchableFlightFilterInput,
    sort?: Array<SearchableFlightSortInput | null>,
    limit?: number,
    nextToken?: string,
    from?: number,
    aggregates?: Array<SearchableFlightAggregationInput | null>
  ): Promise<SearchFlightsQuery> {
    const statement = `query SearchFlights($filter: SearchableFlightFilterInput, $sort: [SearchableFlightSortInput], $limit: Int, $nextToken: String, $from: Int, $aggregates: [SearchableFlightAggregationInput]) {
        searchFlights(filter: $filter, sort: $sort, limit: $limit, nextToken: $nextToken, from: $from, aggregates: $aggregates) {
          __typename
          items {
            __typename
            id
            flightId
            name
            startingLocation
            destination
            createdAt
            updatedAt
          }
          nextToken
          total
          aggregateItems {
            __typename
            name
            result {
              __typename
              ... on SearchableAggregateScalarResult {
                value
              }
              ... on SearchableAggregateBucketResult {
                buckets {
                  __typename
                  key
                  doc_count
                }
              }
            }
          }
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    if (sort) {
      gqlAPIServiceArguments.sort = sort;
    }
    if (limit) {
      gqlAPIServiceArguments.limit = limit;
    }
    if (nextToken) {
      gqlAPIServiceArguments.nextToken = nextToken;
    }
    if (from) {
      gqlAPIServiceArguments.from = from;
    }
    if (aggregates) {
      gqlAPIServiceArguments.aggregates = aggregates;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <SearchFlightsQuery>response.data.searchFlights;
  }
  async SearchBookings(
    filter?: SearchableBookingFilterInput,
    sort?: Array<SearchableBookingSortInput | null>,
    limit?: number,
    nextToken?: string,
    from?: number,
    aggregates?: Array<SearchableBookingAggregationInput | null>
  ): Promise<SearchBookingsQuery> {
    const statement = `query SearchBookings($filter: SearchableBookingFilterInput, $sort: [SearchableBookingSortInput], $limit: Int, $nextToken: String, $from: Int, $aggregates: [SearchableBookingAggregationInput]) {
        searchBookings(filter: $filter, sort: $sort, limit: $limit, nextToken: $nextToken, from: $from, aggregates: $aggregates) {
          __typename
          items {
            __typename
            id
            flightId
            flight {
              __typename
              id
              flightId
              name
              startingLocation
              destination
              createdAt
              updatedAt
            }
            userId
            user {
              __typename
              id
              name
              email
              password
              createdAt
              updatedAt
            }
            passengerName
            noOfTickets
            ticketPrice {
              __typename
              type
              price
            }
            totalAmount
            createdAt
            updatedAt
          }
          nextToken
          total
          aggregateItems {
            __typename
            name
            result {
              __typename
              ... on SearchableAggregateScalarResult {
                value
              }
              ... on SearchableAggregateBucketResult {
                buckets {
                  __typename
                  key
                  doc_count
                }
              }
            }
          }
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    if (sort) {
      gqlAPIServiceArguments.sort = sort;
    }
    if (limit) {
      gqlAPIServiceArguments.limit = limit;
    }
    if (nextToken) {
      gqlAPIServiceArguments.nextToken = nextToken;
    }
    if (from) {
      gqlAPIServiceArguments.from = from;
    }
    if (aggregates) {
      gqlAPIServiceArguments.aggregates = aggregates;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <SearchBookingsQuery>response.data.searchBookings;
  }
  async GetFlight(id: string): Promise<GetFlightQuery> {
    const statement = `query GetFlight($id: ID!) {
        getFlight(id: $id) {
          __typename
          id
          flightId
          name
          startingLocation
          destination
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      id
    };
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <GetFlightQuery>response.data.getFlight;
  }
  async ListFlights(
    filter?: ModelFlightFilterInput,
    limit?: number,
    nextToken?: string
  ): Promise<ListFlightsQuery> {
    const statement = `query ListFlights($filter: ModelFlightFilterInput, $limit: Int, $nextToken: String) {
        listFlights(filter: $filter, limit: $limit, nextToken: $nextToken) {
          __typename
          items {
            __typename
            id
            flightId
            name
            startingLocation
            destination
            createdAt
            updatedAt
          }
          nextToken
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    if (limit) {
      gqlAPIServiceArguments.limit = limit;
    }
    if (nextToken) {
      gqlAPIServiceArguments.nextToken = nextToken;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <ListFlightsQuery>response.data.listFlights;
  }
  async GetBooking(id: string): Promise<GetBookingQuery> {
    const statement = `query GetBooking($id: ID!) {
        getBooking(id: $id) {
          __typename
          id
          flightId
          flight {
            __typename
            id
            flightId
            name
            startingLocation
            destination
            createdAt
            updatedAt
          }
          userId
          user {
            __typename
            id
            name
            email
            password
            createdAt
            updatedAt
          }
          passengerName
          noOfTickets
          ticketPrice {
            __typename
            type
            price
          }
          totalAmount
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      id
    };
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <GetBookingQuery>response.data.getBooking;
  }
  async ListBookings(
    filter?: ModelBookingFilterInput,
    limit?: number,
    nextToken?: string
  ): Promise<ListBookingsQuery> {
    const statement = `query ListBookings($filter: ModelBookingFilterInput, $limit: Int, $nextToken: String) {
        listBookings(filter: $filter, limit: $limit, nextToken: $nextToken) {
          __typename
          items {
            __typename
            id
            flightId
            flight {
              __typename
              id
              flightId
              name
              startingLocation
              destination
              createdAt
              updatedAt
            }
            userId
            user {
              __typename
              id
              name
              email
              password
              createdAt
              updatedAt
            }
            passengerName
            noOfTickets
            ticketPrice {
              __typename
              type
              price
            }
            totalAmount
            createdAt
            updatedAt
          }
          nextToken
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    if (limit) {
      gqlAPIServiceArguments.limit = limit;
    }
    if (nextToken) {
      gqlAPIServiceArguments.nextToken = nextToken;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <ListBookingsQuery>response.data.listBookings;
  }
  async GetUser(id: string): Promise<GetUserQuery> {
    const statement = `query GetUser($id: ID!) {
        getUser(id: $id) {
          __typename
          id
          name
          email
          password
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      id
    };
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <GetUserQuery>response.data.getUser;
  }
  async ListUsers(
    filter?: ModelUserFilterInput,
    limit?: number,
    nextToken?: string
  ): Promise<ListUsersQuery> {
    const statement = `query ListUsers($filter: ModelUserFilterInput, $limit: Int, $nextToken: String) {
        listUsers(filter: $filter, limit: $limit, nextToken: $nextToken) {
          __typename
          items {
            __typename
            id
            name
            email
            password
            createdAt
            updatedAt
          }
          nextToken
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    if (limit) {
      gqlAPIServiceArguments.limit = limit;
    }
    if (nextToken) {
      gqlAPIServiceArguments.nextToken = nextToken;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <ListUsersQuery>response.data.listUsers;
  }
  async FlightByFlightId(
    flightId: string,
    sortDirection?: ModelSortDirection,
    filter?: ModelFlightFilterInput,
    limit?: number,
    nextToken?: string
  ): Promise<FlightByFlightIdQuery> {
    const statement = `query FlightByFlightId($flightId: String!, $sortDirection: ModelSortDirection, $filter: ModelFlightFilterInput, $limit: Int, $nextToken: String) {
        flightByFlightId(flightId: $flightId, sortDirection: $sortDirection, filter: $filter, limit: $limit, nextToken: $nextToken) {
          __typename
          items {
            __typename
            id
            flightId
            name
            startingLocation
            destination
            createdAt
            updatedAt
          }
          nextToken
        }
      }`;
    const gqlAPIServiceArguments: any = {
      flightId
    };
    if (sortDirection) {
      gqlAPIServiceArguments.sortDirection = sortDirection;
    }
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    if (limit) {
      gqlAPIServiceArguments.limit = limit;
    }
    if (nextToken) {
      gqlAPIServiceArguments.nextToken = nextToken;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <FlightByFlightIdQuery>response.data.flightByFlightId;
  }
  OnCreateFlightListener(
    filter?: ModelSubscriptionFlightFilterInput
  ): Observable<
    SubscriptionResponse<Pick<__SubscriptionContainer, "onCreateFlight">>
  > {
    const statement = `subscription OnCreateFlight($filter: ModelSubscriptionFlightFilterInput) {
        onCreateFlight(filter: $filter) {
          __typename
          id
          flightId
          name
          startingLocation
          destination
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    return API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    ) as Observable<
      SubscriptionResponse<Pick<__SubscriptionContainer, "onCreateFlight">>
    >;
  }

  OnUpdateFlightListener(
    filter?: ModelSubscriptionFlightFilterInput
  ): Observable<
    SubscriptionResponse<Pick<__SubscriptionContainer, "onUpdateFlight">>
  > {
    const statement = `subscription OnUpdateFlight($filter: ModelSubscriptionFlightFilterInput) {
        onUpdateFlight(filter: $filter) {
          __typename
          id
          flightId
          name
          startingLocation
          destination
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    return API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    ) as Observable<
      SubscriptionResponse<Pick<__SubscriptionContainer, "onUpdateFlight">>
    >;
  }

  OnDeleteFlightListener(
    filter?: ModelSubscriptionFlightFilterInput
  ): Observable<
    SubscriptionResponse<Pick<__SubscriptionContainer, "onDeleteFlight">>
  > {
    const statement = `subscription OnDeleteFlight($filter: ModelSubscriptionFlightFilterInput) {
        onDeleteFlight(filter: $filter) {
          __typename
          id
          flightId
          name
          startingLocation
          destination
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    return API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    ) as Observable<
      SubscriptionResponse<Pick<__SubscriptionContainer, "onDeleteFlight">>
    >;
  }

  OnCreateBookingListener(
    filter?: ModelSubscriptionBookingFilterInput
  ): Observable<
    SubscriptionResponse<Pick<__SubscriptionContainer, "onCreateBooking">>
  > {
    const statement = `subscription OnCreateBooking($filter: ModelSubscriptionBookingFilterInput) {
        onCreateBooking(filter: $filter) {
          __typename
          id
          flightId
          flight {
            __typename
            id
            flightId
            name
            startingLocation
            destination
            createdAt
            updatedAt
          }
          userId
          user {
            __typename
            id
            name
            email
            password
            createdAt
            updatedAt
          }
          passengerName
          noOfTickets
          ticketPrice {
            __typename
            type
            price
          }
          totalAmount
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    return API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    ) as Observable<
      SubscriptionResponse<Pick<__SubscriptionContainer, "onCreateBooking">>
    >;
  }

  OnUpdateBookingListener(
    filter?: ModelSubscriptionBookingFilterInput
  ): Observable<
    SubscriptionResponse<Pick<__SubscriptionContainer, "onUpdateBooking">>
  > {
    const statement = `subscription OnUpdateBooking($filter: ModelSubscriptionBookingFilterInput) {
        onUpdateBooking(filter: $filter) {
          __typename
          id
          flightId
          flight {
            __typename
            id
            flightId
            name
            startingLocation
            destination
            createdAt
            updatedAt
          }
          userId
          user {
            __typename
            id
            name
            email
            password
            createdAt
            updatedAt
          }
          passengerName
          noOfTickets
          ticketPrice {
            __typename
            type
            price
          }
          totalAmount
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    return API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    ) as Observable<
      SubscriptionResponse<Pick<__SubscriptionContainer, "onUpdateBooking">>
    >;
  }

  OnDeleteBookingListener(
    filter?: ModelSubscriptionBookingFilterInput
  ): Observable<
    SubscriptionResponse<Pick<__SubscriptionContainer, "onDeleteBooking">>
  > {
    const statement = `subscription OnDeleteBooking($filter: ModelSubscriptionBookingFilterInput) {
        onDeleteBooking(filter: $filter) {
          __typename
          id
          flightId
          flight {
            __typename
            id
            flightId
            name
            startingLocation
            destination
            createdAt
            updatedAt
          }
          userId
          user {
            __typename
            id
            name
            email
            password
            createdAt
            updatedAt
          }
          passengerName
          noOfTickets
          ticketPrice {
            __typename
            type
            price
          }
          totalAmount
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    return API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    ) as Observable<
      SubscriptionResponse<Pick<__SubscriptionContainer, "onDeleteBooking">>
    >;
  }

  OnCreateUserListener(
    filter?: ModelSubscriptionUserFilterInput
  ): Observable<
    SubscriptionResponse<Pick<__SubscriptionContainer, "onCreateUser">>
  > {
    const statement = `subscription OnCreateUser($filter: ModelSubscriptionUserFilterInput) {
        onCreateUser(filter: $filter) {
          __typename
          id
          name
          email
          password
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    return API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    ) as Observable<
      SubscriptionResponse<Pick<__SubscriptionContainer, "onCreateUser">>
    >;
  }

  OnUpdateUserListener(
    filter?: ModelSubscriptionUserFilterInput
  ): Observable<
    SubscriptionResponse<Pick<__SubscriptionContainer, "onUpdateUser">>
  > {
    const statement = `subscription OnUpdateUser($filter: ModelSubscriptionUserFilterInput) {
        onUpdateUser(filter: $filter) {
          __typename
          id
          name
          email
          password
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    return API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    ) as Observable<
      SubscriptionResponse<Pick<__SubscriptionContainer, "onUpdateUser">>
    >;
  }

  OnDeleteUserListener(
    filter?: ModelSubscriptionUserFilterInput
  ): Observable<
    SubscriptionResponse<Pick<__SubscriptionContainer, "onDeleteUser">>
  > {
    const statement = `subscription OnDeleteUser($filter: ModelSubscriptionUserFilterInput) {
        onDeleteUser(filter: $filter) {
          __typename
          id
          name
          email
          password
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    return API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    ) as Observable<
      SubscriptionResponse<Pick<__SubscriptionContainer, "onDeleteUser">>
    >;
  }
}
