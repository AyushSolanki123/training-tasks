import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthComponent } from './component/auth/auth.component';
import { HomeComponent } from './component/home/home.component';
import { BookTicketComponent } from './component/book-ticket/book-ticket.component';
import { ViewDetailsComponent } from './component/view-details/view-details.component';
import { PageNotFoundComponent } from './component/page-not-found/page-not-found.component';
import { AuthGuard } from './AuthGuard';

const routes: Routes = [
  {
    path: 'auth',
    component: AuthComponent,
    loadChildren: () =>
      import('./component/auth/auth.module').then((m) => m.AuthModule),
  },
  {
    path: 'home',
    component: HomeComponent,
    canActivate: [AuthGuard],
    loadChildren: () =>
      import('./component/home/home.module').then((m) => m.HomeModule),
  },
  {
    path: 'book-ticket',
    component: BookTicketComponent,
    canActivate: [AuthGuard],
    loadChildren: () =>
      import('./component/book-ticket/book-ticket.module').then(
        (m) => m.BookTicketModule
      ),
  },
  {
    path: 'view-details',
    component: ViewDetailsComponent,
    canActivate: [AuthGuard],
    loadChildren: () =>
      import('./component/view-details/view-details.module').then(
        (m) => m.ViewDetailsModule
      ),
  },
  {
    path: '',
    redirectTo: '/auth/login',
    pathMatch: 'full',
  },
  {
    path: '**',
    component: PageNotFoundComponent,
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
