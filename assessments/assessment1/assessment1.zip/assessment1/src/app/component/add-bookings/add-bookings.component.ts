import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { Movie } from 'src/app/movie/Movie';
import { MovieService } from 'src/app/movie/movie.service';

@Component({
  selector: 'app-add-bookings',
  templateUrl: './add-bookings.component.html',
  styleUrls: ['./add-bookings.component.scss'],
})
export class AddBookingsComponent implements OnInit {
  movieForm!: FormGroup;
  movies!: Movie[];
  movie!: Movie;

  constructor(
    private formBuilder: FormBuilder,
    private movieService: MovieService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.movieForm = this.formBuilder.group({
      id: ['', [Validators.min(1), Validators.max(300)]],
      name: ['', Validators.maxLength(20)],
      bookingDate: ['', Validators.required],
      noOfTickets: [0, Validators.max(15)],
    });
  }

  get id() {
    return this.movieForm.get('id')?.value;
  }

  get name() {
    return this.movieForm.get('name')?.value;
  }

  get bookingDate() {
    return this.movieForm.get('bookingDate')?.value;
  }

  get noOfTickets() {
    return this.movieForm.get('noOfTickets')?.value;
  }

  get amount() {
    return this.noOfTickets * 150;
  }

  submitForm() {
    this.movieService
      .createMovieBooking(
        this.id,
        this.name,
        this.bookingDate,
        this.noOfTickets,
        this.amount
      )
      .subscribe(
        (val) => {
          console.log(val);
          this.router.navigate(['/list-booking']);
        },
        (error) => console.log(error)
      );

    // let movie = new Movie(
    //   this.movies.length + 1,
    //   this.name,
    //   this.bookingDate,
    //   this.noOfTickets,
    //   this.amount
    // );
  }
}
