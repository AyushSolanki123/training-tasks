import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Movie } from 'src/app/movie/Movie';
import { MovieService } from 'src/app/movie/movie.service';

@Component({
  selector: 'app-list-bookings',
  templateUrl: './list-bookings.component.html',
  styleUrls: ['./list-bookings.component.scss'],
})
export class ListBookingsComponent implements OnInit {
  movies!: Movie[];
  errorMessage!: string;
  constructor(private movieService: MovieService, private router: Router) {}

  getAllBookings() {
    this.movieService.getMovieBooking().subscribe((val) => (this.movies = val));
  }

  navigateToAddBooking() {
    this.router.navigateByUrl('/add-booking');
  }

  navigateToUpdateBooking(id: number) {
    this.router.navigateByUrl(`/update-booking/${id}`);
  }

  deleteBookings(id: number) {
    this.movieService.deleteMovieBooking(id).subscribe((e) => {
      this.getAllBookings();
    });
  }

  ngOnInit(): void {
    this.getAllBookings();
  }
}
