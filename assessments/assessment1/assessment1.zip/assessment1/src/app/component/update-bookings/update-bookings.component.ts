import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { Movie } from 'src/app/movie/Movie';
import { MovieService } from 'src/app/movie/movie.service';

@Component({
  selector: 'app-update-bookings',
  templateUrl: './update-bookings.component.html',
  styleUrls: ['./update-bookings.component.scss'],
})
export class UpdateBookingsComponent {
  movieForm!: FormGroup;
  movie!: Movie | undefined;
  movieId!: number;

  constructor(
    private formBuilder: FormBuilder,
    private movieService: MovieService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.route.params.subscribe((p) => (this.movieId = p['id']));
    this.movieForm = this.formBuilder.group({
      name: ['', Validators.maxLength(20)],
      bookingDate: ['', Validators.required],
      noOfTickets: [0, Validators.max(15)],
    });
  }

  get name() {
    return this.movieForm.get('name')?.value;
  }

  get bookingDate() {
    return this.movieForm.get('bookingDate')?.value;
  }

  get noOfTickets() {
    return this.movieForm.get('noOfTickets')?.value;
  }

  get amount() {
    return this.noOfTickets * 150;
  }

  submitForm() {
    let movie = new Movie(
      this.movieId,
      this.name,
      this.bookingDate,
      this.noOfTickets,
      this.amount
    );
    this.movieService.updateMovieBooking(this.movieId, movie).subscribe(
      (val) => {
        console.log(val);
        this.router.navigate(['/list-booking']);
      },
      (error) => {
        console.log(error);
      }
    );
  }
}
