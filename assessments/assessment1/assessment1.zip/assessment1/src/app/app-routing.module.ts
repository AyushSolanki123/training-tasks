import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddBookingsComponent } from './component/add-bookings/add-bookings.component';
import { ListBookingsComponent } from './component/list-bookings/list-bookings.component';
import { UpdateBookingsComponent } from './component/update-bookings/update-bookings.component';

const routes: Routes = [
  {
    path: 'list-booking',
    component: ListBookingsComponent,
  },
  {
    path: 'add-booking',
    component: AddBookingsComponent,
  },
  {
    path: 'update-booking/:id',
    component: UpdateBookingsComponent,
  },
  { path: '', redirectTo: '/list-booking', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
