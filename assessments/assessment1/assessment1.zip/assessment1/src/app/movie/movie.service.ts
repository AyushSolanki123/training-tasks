import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Movie } from './Movie';

@Injectable({
  providedIn: 'root',
})
export class MovieService {
  private bookingUrl = 'http://localhost:3000/bookings';
  movies!: Movie[];

  constructor(private http: HttpClient) {}

  getMovieBooking(): Observable<Movie[]> {
    return this.http.get<Movie[]>(this.bookingUrl);
  }

  createMovieBooking(
    id: number,
    name: string,
    date: string,
    no: number,
    amount: number
  ) {
    let movie = new Movie(id, name, date, no, amount);
    return this.http.post<Movie>(this.bookingUrl, movie);
  }

  updateMovieBooking(id: number, booking: Movie) {
    return this.http.put<Movie>(`${this.bookingUrl}/${id}`, booking);
  }

  deleteMovieBooking(id: number) {
    return this.http.delete(this.bookingUrl + '/' + id);
  }
}
