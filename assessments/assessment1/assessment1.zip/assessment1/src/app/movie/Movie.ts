export class Movie {
  id!: number;
  movieName!: string;
  movieBookingDate!: string;
  noOfTickets!: number;
  totalAmount!: number;

  constructor(
    id: number,
    name: string,
    date: string,
    no: number,
    amount: number
  ) {
    this.id = id;
    this.movieName = name;
    this.movieBookingDate = date;
    this.noOfTickets = no;
    this.totalAmount = amount;
  }
}
