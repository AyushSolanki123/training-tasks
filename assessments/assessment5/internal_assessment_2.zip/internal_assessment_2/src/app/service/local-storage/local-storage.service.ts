import { Injectable } from '@angular/core';

const CURRENT_CART_ID = 'currentCartId';
const CURRENT_USER_ID = 'currentUserId';

@Injectable({
  providedIn: 'root',
})
export class LocalStorageService {
  constructor() {}

  setCurrentCartIdInLocalStorage(cartId: string) {
    localStorage.setItem(CURRENT_CART_ID, cartId);
  }

  getCurrentCartIdFromLocalStorage() {
    return localStorage.getItem(CURRENT_CART_ID);
  }

  removeCurrentCartIdFromLocalStorage() {
    localStorage.removeItem(CURRENT_CART_ID);
  }

  setCurrentUserIdInLocalStorage(userId: string) {
    localStorage.setItem(CURRENT_USER_ID, userId);
  }

  getCurrentUserIdFromLocalStorage() {
    return localStorage.getItem(CURRENT_USER_ID);
  }

  removeCurrentUserIdFromLocalStorage() {
    localStorage.removeItem(CURRENT_USER_ID);
  }
}
