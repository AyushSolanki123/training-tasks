/* tslint:disable */
/* eslint-disable */
//  This file was automatically generated and should not be edited.
import { Injectable } from "@angular/core";
import API, { graphqlOperation, GraphQLResult } from "@aws-amplify/api-graphql";
import { Observable } from "zen-observable-ts";

export interface SubscriptionResponse<T> {
  value: GraphQLResult<T>;
}

export type __SubscriptionContainer = {
  onCreateItem: OnCreateItemSubscription;
  onUpdateItem: OnUpdateItemSubscription;
  onDeleteItem: OnDeleteItemSubscription;
  onCreateUser: OnCreateUserSubscription;
  onUpdateUser: OnUpdateUserSubscription;
  onDeleteUser: OnDeleteUserSubscription;
  onCreateCartItem: OnCreateCartItemSubscription;
  onUpdateCartItem: OnUpdateCartItemSubscription;
  onDeleteCartItem: OnDeleteCartItemSubscription;
  onCreateCart: OnCreateCartSubscription;
  onUpdateCart: OnUpdateCartSubscription;
  onDeleteCart: OnDeleteCartSubscription;
};

export type CreateItemInput = {
  id?: string | null;
  title: string;
  price: string;
  category: string;
  description?: string | null;
  image?: string | null;
};

export type ModelItemConditionInput = {
  title?: ModelStringInput | null;
  price?: ModelStringInput | null;
  category?: ModelStringInput | null;
  description?: ModelStringInput | null;
  image?: ModelStringInput | null;
  and?: Array<ModelItemConditionInput | null> | null;
  or?: Array<ModelItemConditionInput | null> | null;
  not?: ModelItemConditionInput | null;
};

export type ModelStringInput = {
  ne?: string | null;
  eq?: string | null;
  le?: string | null;
  lt?: string | null;
  ge?: string | null;
  gt?: string | null;
  contains?: string | null;
  notContains?: string | null;
  between?: Array<string | null> | null;
  beginsWith?: string | null;
  attributeExists?: boolean | null;
  attributeType?: ModelAttributeTypes | null;
  size?: ModelSizeInput | null;
};

export enum ModelAttributeTypes {
  binary = "binary",
  binarySet = "binarySet",
  bool = "bool",
  list = "list",
  map = "map",
  number = "number",
  numberSet = "numberSet",
  string = "string",
  stringSet = "stringSet",
  _null = "_null"
}

export type ModelSizeInput = {
  ne?: number | null;
  eq?: number | null;
  le?: number | null;
  lt?: number | null;
  ge?: number | null;
  gt?: number | null;
  between?: Array<number | null> | null;
};

export type Item = {
  __typename: "Item";
  id: string;
  title: string;
  price: string;
  category: string;
  description?: string | null;
  image?: string | null;
  createdAt: string;
  updatedAt: string;
};

export type UpdateItemInput = {
  id: string;
  title?: string | null;
  price?: string | null;
  category?: string | null;
  description?: string | null;
  image?: string | null;
};

export type DeleteItemInput = {
  id: string;
};

export type CreateUserInput = {
  id?: string | null;
  firstName: string;
  lastName?: string | null;
  email: string;
  password: string;
  phone?: string | null;
};

export type ModelUserConditionInput = {
  firstName?: ModelStringInput | null;
  lastName?: ModelStringInput | null;
  email?: ModelStringInput | null;
  password?: ModelStringInput | null;
  phone?: ModelStringInput | null;
  and?: Array<ModelUserConditionInput | null> | null;
  or?: Array<ModelUserConditionInput | null> | null;
  not?: ModelUserConditionInput | null;
};

export type User = {
  __typename: "User";
  id: string;
  firstName: string;
  lastName?: string | null;
  email: string;
  password: string;
  phone?: string | null;
  createdAt: string;
  updatedAt: string;
};

export type UpdateUserInput = {
  id: string;
  firstName?: string | null;
  lastName?: string | null;
  email?: string | null;
  password?: string | null;
  phone?: string | null;
};

export type DeleteUserInput = {
  id: string;
};

export type CreateCartItemInput = {
  id?: string | null;
  quantity: number;
  itemId: string;
  cartId: string;
};

export type ModelCartItemConditionInput = {
  quantity?: ModelIntInput | null;
  itemId?: ModelIDInput | null;
  cartId?: ModelIDInput | null;
  and?: Array<ModelCartItemConditionInput | null> | null;
  or?: Array<ModelCartItemConditionInput | null> | null;
  not?: ModelCartItemConditionInput | null;
};

export type ModelIntInput = {
  ne?: number | null;
  eq?: number | null;
  le?: number | null;
  lt?: number | null;
  ge?: number | null;
  gt?: number | null;
  between?: Array<number | null> | null;
  attributeExists?: boolean | null;
  attributeType?: ModelAttributeTypes | null;
};

export type ModelIDInput = {
  ne?: string | null;
  eq?: string | null;
  le?: string | null;
  lt?: string | null;
  ge?: string | null;
  gt?: string | null;
  contains?: string | null;
  notContains?: string | null;
  between?: Array<string | null> | null;
  beginsWith?: string | null;
  attributeExists?: boolean | null;
  attributeType?: ModelAttributeTypes | null;
  size?: ModelSizeInput | null;
};

export type CartItem = {
  __typename: "CartItem";
  id: string;
  quantity: number;
  itemId: string;
  item?: Item | null;
  cartId: string;
  cart?: Cart | null;
  createdAt: string;
  updatedAt: string;
};

export type Cart = {
  __typename: "Cart";
  id: string;
  checkedOut?: boolean | null;
  userId: string;
  user?: User | null;
  items?: ModelCartItemConnection | null;
  createdAt: string;
  updatedAt: string;
};

export type ModelCartItemConnection = {
  __typename: "ModelCartItemConnection";
  items: Array<CartItem | null>;
  nextToken?: string | null;
};

export type UpdateCartItemInput = {
  id: string;
  quantity?: number | null;
  itemId?: string | null;
  cartId?: string | null;
};

export type DeleteCartItemInput = {
  id: string;
};

export type CreateCartInput = {
  id?: string | null;
  checkedOut?: boolean | null;
  userId: string;
};

export type ModelCartConditionInput = {
  checkedOut?: ModelBooleanInput | null;
  userId?: ModelIDInput | null;
  and?: Array<ModelCartConditionInput | null> | null;
  or?: Array<ModelCartConditionInput | null> | null;
  not?: ModelCartConditionInput | null;
};

export type ModelBooleanInput = {
  ne?: boolean | null;
  eq?: boolean | null;
  attributeExists?: boolean | null;
  attributeType?: ModelAttributeTypes | null;
};

export type UpdateCartInput = {
  id: string;
  checkedOut?: boolean | null;
  userId?: string | null;
};

export type DeleteCartInput = {
  id: string;
};

export type SearchableItemFilterInput = {
  id?: SearchableIDFilterInput | null;
  title?: SearchableStringFilterInput | null;
  price?: SearchableStringFilterInput | null;
  category?: SearchableStringFilterInput | null;
  description?: SearchableStringFilterInput | null;
  image?: SearchableStringFilterInput | null;
  createdAt?: SearchableStringFilterInput | null;
  updatedAt?: SearchableStringFilterInput | null;
  and?: Array<SearchableItemFilterInput | null> | null;
  or?: Array<SearchableItemFilterInput | null> | null;
  not?: SearchableItemFilterInput | null;
};

export type SearchableIDFilterInput = {
  ne?: string | null;
  gt?: string | null;
  lt?: string | null;
  gte?: string | null;
  lte?: string | null;
  eq?: string | null;
  match?: string | null;
  matchPhrase?: string | null;
  matchPhrasePrefix?: string | null;
  multiMatch?: string | null;
  exists?: boolean | null;
  wildcard?: string | null;
  regexp?: string | null;
  range?: Array<string | null> | null;
};

export type SearchableStringFilterInput = {
  ne?: string | null;
  gt?: string | null;
  lt?: string | null;
  gte?: string | null;
  lte?: string | null;
  eq?: string | null;
  match?: string | null;
  matchPhrase?: string | null;
  matchPhrasePrefix?: string | null;
  multiMatch?: string | null;
  exists?: boolean | null;
  wildcard?: string | null;
  regexp?: string | null;
  range?: Array<string | null> | null;
};

export type SearchableItemSortInput = {
  field?: SearchableItemSortableFields | null;
  direction?: SearchableSortDirection | null;
};

export enum SearchableItemSortableFields {
  id = "id",
  title = "title",
  price = "price",
  category = "category",
  description = "description",
  image = "image",
  createdAt = "createdAt",
  updatedAt = "updatedAt"
}

export enum SearchableSortDirection {
  asc = "asc",
  desc = "desc"
}

export type SearchableItemAggregationInput = {
  name: string;
  type: SearchableAggregateType;
  field: SearchableItemAggregateField;
};

export enum SearchableAggregateType {
  terms = "terms",
  avg = "avg",
  min = "min",
  max = "max",
  sum = "sum"
}

export enum SearchableItemAggregateField {
  id = "id",
  title = "title",
  price = "price",
  category = "category",
  description = "description",
  image = "image",
  createdAt = "createdAt",
  updatedAt = "updatedAt"
}

export type SearchableItemConnection = {
  __typename: "SearchableItemConnection";
  items: Array<Item | null>;
  nextToken?: string | null;
  total?: number | null;
  aggregateItems: Array<SearchableAggregateResult | null>;
};

export type SearchableAggregateResult = {
  __typename: "SearchableAggregateResult";
  name: string;
  result?: SearchableAggregateGenericResult | null;
};

export type SearchableAggregateGenericResult =
  | SearchableAggregateScalarResult
  | SearchableAggregateBucketResult;

export type SearchableAggregateScalarResult = {
  __typename: "SearchableAggregateScalarResult";
  value: number;
};

export type SearchableAggregateBucketResult = {
  __typename: "SearchableAggregateBucketResult";
  buckets?: Array<SearchableAggregateBucketResultItem | null> | null;
};

export type SearchableAggregateBucketResultItem = {
  __typename: "SearchableAggregateBucketResultItem";
  key: string;
  doc_count: number;
};

export type SearchableCartFilterInput = {
  id?: SearchableIDFilterInput | null;
  checkedOut?: SearchableBooleanFilterInput | null;
  userId?: SearchableIDFilterInput | null;
  createdAt?: SearchableStringFilterInput | null;
  updatedAt?: SearchableStringFilterInput | null;
  and?: Array<SearchableCartFilterInput | null> | null;
  or?: Array<SearchableCartFilterInput | null> | null;
  not?: SearchableCartFilterInput | null;
};

export type SearchableBooleanFilterInput = {
  eq?: boolean | null;
  ne?: boolean | null;
};

export type SearchableCartSortInput = {
  field?: SearchableCartSortableFields | null;
  direction?: SearchableSortDirection | null;
};

export enum SearchableCartSortableFields {
  id = "id",
  checkedOut = "checkedOut",
  userId = "userId",
  createdAt = "createdAt",
  updatedAt = "updatedAt"
}

export type SearchableCartAggregationInput = {
  name: string;
  type: SearchableAggregateType;
  field: SearchableCartAggregateField;
};

export enum SearchableCartAggregateField {
  id = "id",
  checkedOut = "checkedOut",
  userId = "userId",
  createdAt = "createdAt",
  updatedAt = "updatedAt"
}

export type SearchableCartConnection = {
  __typename: "SearchableCartConnection";
  items: Array<Cart | null>;
  nextToken?: string | null;
  total?: number | null;
  aggregateItems: Array<SearchableAggregateResult | null>;
};

export type ModelItemFilterInput = {
  id?: ModelIDInput | null;
  title?: ModelStringInput | null;
  price?: ModelStringInput | null;
  category?: ModelStringInput | null;
  description?: ModelStringInput | null;
  image?: ModelStringInput | null;
  and?: Array<ModelItemFilterInput | null> | null;
  or?: Array<ModelItemFilterInput | null> | null;
  not?: ModelItemFilterInput | null;
};

export type ModelItemConnection = {
  __typename: "ModelItemConnection";
  items: Array<Item | null>;
  nextToken?: string | null;
};

export type ModelUserFilterInput = {
  id?: ModelIDInput | null;
  firstName?: ModelStringInput | null;
  lastName?: ModelStringInput | null;
  email?: ModelStringInput | null;
  password?: ModelStringInput | null;
  phone?: ModelStringInput | null;
  and?: Array<ModelUserFilterInput | null> | null;
  or?: Array<ModelUserFilterInput | null> | null;
  not?: ModelUserFilterInput | null;
};

export type ModelUserConnection = {
  __typename: "ModelUserConnection";
  items: Array<User | null>;
  nextToken?: string | null;
};

export type ModelCartItemFilterInput = {
  id?: ModelIDInput | null;
  quantity?: ModelIntInput | null;
  itemId?: ModelIDInput | null;
  cartId?: ModelIDInput | null;
  and?: Array<ModelCartItemFilterInput | null> | null;
  or?: Array<ModelCartItemFilterInput | null> | null;
  not?: ModelCartItemFilterInput | null;
};

export type ModelCartFilterInput = {
  id?: ModelIDInput | null;
  checkedOut?: ModelBooleanInput | null;
  userId?: ModelIDInput | null;
  and?: Array<ModelCartFilterInput | null> | null;
  or?: Array<ModelCartFilterInput | null> | null;
  not?: ModelCartFilterInput | null;
};

export type ModelCartConnection = {
  __typename: "ModelCartConnection";
  items: Array<Cart | null>;
  nextToken?: string | null;
};

export enum ModelSortDirection {
  ASC = "ASC",
  DESC = "DESC"
}

export type ModelSubscriptionItemFilterInput = {
  id?: ModelSubscriptionIDInput | null;
  title?: ModelSubscriptionStringInput | null;
  price?: ModelSubscriptionStringInput | null;
  category?: ModelSubscriptionStringInput | null;
  description?: ModelSubscriptionStringInput | null;
  image?: ModelSubscriptionStringInput | null;
  and?: Array<ModelSubscriptionItemFilterInput | null> | null;
  or?: Array<ModelSubscriptionItemFilterInput | null> | null;
};

export type ModelSubscriptionIDInput = {
  ne?: string | null;
  eq?: string | null;
  le?: string | null;
  lt?: string | null;
  ge?: string | null;
  gt?: string | null;
  contains?: string | null;
  notContains?: string | null;
  between?: Array<string | null> | null;
  beginsWith?: string | null;
  in?: Array<string | null> | null;
  notIn?: Array<string | null> | null;
};

export type ModelSubscriptionStringInput = {
  ne?: string | null;
  eq?: string | null;
  le?: string | null;
  lt?: string | null;
  ge?: string | null;
  gt?: string | null;
  contains?: string | null;
  notContains?: string | null;
  between?: Array<string | null> | null;
  beginsWith?: string | null;
  in?: Array<string | null> | null;
  notIn?: Array<string | null> | null;
};

export type ModelSubscriptionUserFilterInput = {
  id?: ModelSubscriptionIDInput | null;
  firstName?: ModelSubscriptionStringInput | null;
  lastName?: ModelSubscriptionStringInput | null;
  email?: ModelSubscriptionStringInput | null;
  password?: ModelSubscriptionStringInput | null;
  phone?: ModelSubscriptionStringInput | null;
  and?: Array<ModelSubscriptionUserFilterInput | null> | null;
  or?: Array<ModelSubscriptionUserFilterInput | null> | null;
};

export type ModelSubscriptionCartItemFilterInput = {
  id?: ModelSubscriptionIDInput | null;
  quantity?: ModelSubscriptionIntInput | null;
  itemId?: ModelSubscriptionIDInput | null;
  cartId?: ModelSubscriptionIDInput | null;
  and?: Array<ModelSubscriptionCartItemFilterInput | null> | null;
  or?: Array<ModelSubscriptionCartItemFilterInput | null> | null;
};

export type ModelSubscriptionIntInput = {
  ne?: number | null;
  eq?: number | null;
  le?: number | null;
  lt?: number | null;
  ge?: number | null;
  gt?: number | null;
  between?: Array<number | null> | null;
  in?: Array<number | null> | null;
  notIn?: Array<number | null> | null;
};

export type ModelSubscriptionCartFilterInput = {
  id?: ModelSubscriptionIDInput | null;
  checkedOut?: ModelSubscriptionBooleanInput | null;
  userId?: ModelSubscriptionIDInput | null;
  and?: Array<ModelSubscriptionCartFilterInput | null> | null;
  or?: Array<ModelSubscriptionCartFilterInput | null> | null;
};

export type ModelSubscriptionBooleanInput = {
  ne?: boolean | null;
  eq?: boolean | null;
};

export type CreateItemMutation = {
  __typename: "Item";
  id: string;
  title: string;
  price: string;
  category: string;
  description?: string | null;
  image?: string | null;
  createdAt: string;
  updatedAt: string;
};

export type UpdateItemMutation = {
  __typename: "Item";
  id: string;
  title: string;
  price: string;
  category: string;
  description?: string | null;
  image?: string | null;
  createdAt: string;
  updatedAt: string;
};

export type DeleteItemMutation = {
  __typename: "Item";
  id: string;
  title: string;
  price: string;
  category: string;
  description?: string | null;
  image?: string | null;
  createdAt: string;
  updatedAt: string;
};

export type CreateUserMutation = {
  __typename: "User";
  id: string;
  firstName: string;
  lastName?: string | null;
  email: string;
  password: string;
  phone?: string | null;
  createdAt: string;
  updatedAt: string;
};

export type UpdateUserMutation = {
  __typename: "User";
  id: string;
  firstName: string;
  lastName?: string | null;
  email: string;
  password: string;
  phone?: string | null;
  createdAt: string;
  updatedAt: string;
};

export type DeleteUserMutation = {
  __typename: "User";
  id: string;
  firstName: string;
  lastName?: string | null;
  email: string;
  password: string;
  phone?: string | null;
  createdAt: string;
  updatedAt: string;
};

export type CreateCartItemMutation = {
  __typename: "CartItem";
  id: string;
  quantity: number;
  itemId: string;
  item?: {
    __typename: "Item";
    id: string;
    title: string;
    price: string;
    category: string;
    description?: string | null;
    image?: string | null;
    createdAt: string;
    updatedAt: string;
  } | null;
  cartId: string;
  cart?: {
    __typename: "Cart";
    id: string;
    checkedOut?: boolean | null;
    userId: string;
    user?: {
      __typename: "User";
      id: string;
      firstName: string;
      lastName?: string | null;
      email: string;
      password: string;
      phone?: string | null;
      createdAt: string;
      updatedAt: string;
    } | null;
    items?: {
      __typename: "ModelCartItemConnection";
      nextToken?: string | null;
    } | null;
    createdAt: string;
    updatedAt: string;
  } | null;
  createdAt: string;
  updatedAt: string;
};

export type UpdateCartItemMutation = {
  __typename: "CartItem";
  id: string;
  quantity: number;
  itemId: string;
  item?: {
    __typename: "Item";
    id: string;
    title: string;
    price: string;
    category: string;
    description?: string | null;
    image?: string | null;
    createdAt: string;
    updatedAt: string;
  } | null;
  cartId: string;
  cart?: {
    __typename: "Cart";
    id: string;
    checkedOut?: boolean | null;
    userId: string;
    user?: {
      __typename: "User";
      id: string;
      firstName: string;
      lastName?: string | null;
      email: string;
      password: string;
      phone?: string | null;
      createdAt: string;
      updatedAt: string;
    } | null;
    items?: {
      __typename: "ModelCartItemConnection";
      nextToken?: string | null;
    } | null;
    createdAt: string;
    updatedAt: string;
  } | null;
  createdAt: string;
  updatedAt: string;
};

export type DeleteCartItemMutation = {
  __typename: "CartItem";
  id: string;
  quantity: number;
  itemId: string;
  item?: {
    __typename: "Item";
    id: string;
    title: string;
    price: string;
    category: string;
    description?: string | null;
    image?: string | null;
    createdAt: string;
    updatedAt: string;
  } | null;
  cartId: string;
  cart?: {
    __typename: "Cart";
    id: string;
    checkedOut?: boolean | null;
    userId: string;
    user?: {
      __typename: "User";
      id: string;
      firstName: string;
      lastName?: string | null;
      email: string;
      password: string;
      phone?: string | null;
      createdAt: string;
      updatedAt: string;
    } | null;
    items?: {
      __typename: "ModelCartItemConnection";
      nextToken?: string | null;
    } | null;
    createdAt: string;
    updatedAt: string;
  } | null;
  createdAt: string;
  updatedAt: string;
};

export type CreateCartMutation = {
  __typename: "Cart";
  id: string;
  checkedOut?: boolean | null;
  userId: string;
  user?: {
    __typename: "User";
    id: string;
    firstName: string;
    lastName?: string | null;
    email: string;
    password: string;
    phone?: string | null;
    createdAt: string;
    updatedAt: string;
  } | null;
  items?: {
    __typename: "ModelCartItemConnection";
    items: Array<{
      __typename: "CartItem";
      id: string;
      quantity: number;
      itemId: string;
      cartId: string;
      createdAt: string;
      updatedAt: string;
    } | null>;
    nextToken?: string | null;
  } | null;
  createdAt: string;
  updatedAt: string;
};

export type UpdateCartMutation = {
  __typename: "Cart";
  id: string;
  checkedOut?: boolean | null;
  userId: string;
  user?: {
    __typename: "User";
    id: string;
    firstName: string;
    lastName?: string | null;
    email: string;
    password: string;
    phone?: string | null;
    createdAt: string;
    updatedAt: string;
  } | null;
  items?: {
    __typename: "ModelCartItemConnection";
    items: Array<{
      __typename: "CartItem";
      id: string;
      quantity: number;
      itemId: string;
      cartId: string;
      createdAt: string;
      updatedAt: string;
    } | null>;
    nextToken?: string | null;
  } | null;
  createdAt: string;
  updatedAt: string;
};

export type DeleteCartMutation = {
  __typename: "Cart";
  id: string;
  checkedOut?: boolean | null;
  userId: string;
  user?: {
    __typename: "User";
    id: string;
    firstName: string;
    lastName?: string | null;
    email: string;
    password: string;
    phone?: string | null;
    createdAt: string;
    updatedAt: string;
  } | null;
  items?: {
    __typename: "ModelCartItemConnection";
    items: Array<{
      __typename: "CartItem";
      id: string;
      quantity: number;
      itemId: string;
      cartId: string;
      createdAt: string;
      updatedAt: string;
    } | null>;
    nextToken?: string | null;
  } | null;
  createdAt: string;
  updatedAt: string;
};

export type SearchItemsQuery = {
  __typename: "SearchableItemConnection";
  items: Array<{
    __typename: "Item";
    id: string;
    title: string;
    price: string;
    category: string;
    description?: string | null;
    image?: string | null;
    createdAt: string;
    updatedAt: string;
  } | null>;
  nextToken?: string | null;
  total?: number | null;
  aggregateItems: Array<{
    __typename: "SearchableAggregateResult";
    name: string;
    result:
      | (
          | {
              __typename: "SearchableAggregateScalarResult";
              value: number;
            }
          | {
              __typename: "SearchableAggregateBucketResult";
              buckets?: Array<{
                __typename: string;
                key: string;
                doc_count: number;
              } | null> | null;
            }
        )
      | null;
  } | null>;
};

export type SearchCartsQuery = {
  __typename: "SearchableCartConnection";
  items: Array<{
    __typename: "Cart";
    id: string;
    checkedOut?: boolean | null;
    userId: string;
    user?: {
      __typename: "User";
      id: string;
      firstName: string;
      lastName?: string | null;
      email: string;
      password: string;
      phone?: string | null;
      createdAt: string;
      updatedAt: string;
    } | null;
    items?: {
      __typename: "ModelCartItemConnection";
      nextToken?: string | null;
    } | null;
    createdAt: string;
    updatedAt: string;
  } | null>;
  nextToken?: string | null;
  total?: number | null;
  aggregateItems: Array<{
    __typename: "SearchableAggregateResult";
    name: string;
    result:
      | (
          | {
              __typename: "SearchableAggregateScalarResult";
              value: number;
            }
          | {
              __typename: "SearchableAggregateBucketResult";
              buckets?: Array<{
                __typename: string;
                key: string;
                doc_count: number;
              } | null> | null;
            }
        )
      | null;
  } | null>;
};

export type GetItemQuery = {
  __typename: "Item";
  id: string;
  title: string;
  price: string;
  category: string;
  description?: string | null;
  image?: string | null;
  createdAt: string;
  updatedAt: string;
};

export type ListItemsQuery = {
  __typename: "ModelItemConnection";
  items: Array<{
    __typename: "Item";
    id: string;
    title: string;
    price: string;
    category: string;
    description?: string | null;
    image?: string | null;
    createdAt: string;
    updatedAt: string;
  } | null>;
  nextToken?: string | null;
};

export type GetUserQuery = {
  __typename: "User";
  id: string;
  firstName: string;
  lastName?: string | null;
  email: string;
  password: string;
  phone?: string | null;
  createdAt: string;
  updatedAt: string;
};

export type ListUsersQuery = {
  __typename: "ModelUserConnection";
  items: Array<{
    __typename: "User";
    id: string;
    firstName: string;
    lastName?: string | null;
    email: string;
    password: string;
    phone?: string | null;
    createdAt: string;
    updatedAt: string;
  } | null>;
  nextToken?: string | null;
};

export type GetCartItemQuery = {
  __typename: "CartItem";
  id: string;
  quantity: number;
  itemId: string;
  item?: {
    __typename: "Item";
    id: string;
    title: string;
    price: string;
    category: string;
    description?: string | null;
    image?: string | null;
    createdAt: string;
    updatedAt: string;
  } | null;
  cartId: string;
  cart?: {
    __typename: "Cart";
    id: string;
    checkedOut?: boolean | null;
    userId: string;
    user?: {
      __typename: "User";
      id: string;
      firstName: string;
      lastName?: string | null;
      email: string;
      password: string;
      phone?: string | null;
      createdAt: string;
      updatedAt: string;
    } | null;
    items?: {
      __typename: "ModelCartItemConnection";
      nextToken?: string | null;
    } | null;
    createdAt: string;
    updatedAt: string;
  } | null;
  createdAt: string;
  updatedAt: string;
};

export type ListCartItemsQuery = {
  __typename: "ModelCartItemConnection";
  items: Array<{
    __typename: "CartItem";
    id: string;
    quantity: number;
    itemId: string;
    item?: {
      __typename: "Item";
      id: string;
      title: string;
      price: string;
      category: string;
      description?: string | null;
      image?: string | null;
      createdAt: string;
      updatedAt: string;
    } | null;
    cartId: string;
    cart?: {
      __typename: "Cart";
      id: string;
      checkedOut?: boolean | null;
      userId: string;
      createdAt: string;
      updatedAt: string;
    } | null;
    createdAt: string;
    updatedAt: string;
  } | null>;
  nextToken?: string | null;
};

export type GetCartQuery = {
  __typename: "Cart";
  id: string;
  checkedOut?: boolean | null;
  userId: string;
  user?: {
    __typename: "User";
    id: string;
    firstName: string;
    lastName?: string | null;
    email: string;
    password: string;
    phone?: string | null;
    createdAt: string;
    updatedAt: string;
  } | null;
  items?: {
    __typename: "ModelCartItemConnection";
    items: Array<{
      __typename: "CartItem";
      id: string;
      quantity: number;
      itemId: string;
      cartId: string;
      createdAt: string;
      updatedAt: string;
    } | null>;
    nextToken?: string | null;
  } | null;
  createdAt: string;
  updatedAt: string;
};

export type ListCartsQuery = {
  __typename: "ModelCartConnection";
  items: Array<{
    __typename: "Cart";
    id: string;
    checkedOut?: boolean | null;
    userId: string;
    user?: {
      __typename: "User";
      id: string;
      firstName: string;
      lastName?: string | null;
      email: string;
      password: string;
      phone?: string | null;
      createdAt: string;
      updatedAt: string;
    } | null;
    items?: {
      __typename: "ModelCartItemConnection";
      nextToken?: string | null;
    } | null;
    createdAt: string;
    updatedAt: string;
  } | null>;
  nextToken?: string | null;
};

export type CartItemsByCartQuery = {
  __typename: "ModelCartItemConnection";
  items: Array<{
    __typename: "CartItem";
    id: string;
    quantity: number;
    itemId: string;
    item?: {
      __typename: "Item";
      id: string;
      title: string;
      price: string;
      category: string;
      description?: string | null;
      image?: string | null;
      createdAt: string;
      updatedAt: string;
    } | null;
    cartId: string;
    cart?: {
      __typename: "Cart";
      id: string;
      checkedOut?: boolean | null;
      userId: string;
      createdAt: string;
      updatedAt: string;
    } | null;
    createdAt: string;
    updatedAt: string;
  } | null>;
  nextToken?: string | null;
};

export type OnCreateItemSubscription = {
  __typename: "Item";
  id: string;
  title: string;
  price: string;
  category: string;
  description?: string | null;
  image?: string | null;
  createdAt: string;
  updatedAt: string;
};

export type OnUpdateItemSubscription = {
  __typename: "Item";
  id: string;
  title: string;
  price: string;
  category: string;
  description?: string | null;
  image?: string | null;
  createdAt: string;
  updatedAt: string;
};

export type OnDeleteItemSubscription = {
  __typename: "Item";
  id: string;
  title: string;
  price: string;
  category: string;
  description?: string | null;
  image?: string | null;
  createdAt: string;
  updatedAt: string;
};

export type OnCreateUserSubscription = {
  __typename: "User";
  id: string;
  firstName: string;
  lastName?: string | null;
  email: string;
  password: string;
  phone?: string | null;
  createdAt: string;
  updatedAt: string;
};

export type OnUpdateUserSubscription = {
  __typename: "User";
  id: string;
  firstName: string;
  lastName?: string | null;
  email: string;
  password: string;
  phone?: string | null;
  createdAt: string;
  updatedAt: string;
};

export type OnDeleteUserSubscription = {
  __typename: "User";
  id: string;
  firstName: string;
  lastName?: string | null;
  email: string;
  password: string;
  phone?: string | null;
  createdAt: string;
  updatedAt: string;
};

export type OnCreateCartItemSubscription = {
  __typename: "CartItem";
  id: string;
  quantity: number;
  itemId: string;
  item?: {
    __typename: "Item";
    id: string;
    title: string;
    price: string;
    category: string;
    description?: string | null;
    image?: string | null;
    createdAt: string;
    updatedAt: string;
  } | null;
  cartId: string;
  cart?: {
    __typename: "Cart";
    id: string;
    checkedOut?: boolean | null;
    userId: string;
    user?: {
      __typename: "User";
      id: string;
      firstName: string;
      lastName?: string | null;
      email: string;
      password: string;
      phone?: string | null;
      createdAt: string;
      updatedAt: string;
    } | null;
    items?: {
      __typename: "ModelCartItemConnection";
      nextToken?: string | null;
    } | null;
    createdAt: string;
    updatedAt: string;
  } | null;
  createdAt: string;
  updatedAt: string;
};

export type OnUpdateCartItemSubscription = {
  __typename: "CartItem";
  id: string;
  quantity: number;
  itemId: string;
  item?: {
    __typename: "Item";
    id: string;
    title: string;
    price: string;
    category: string;
    description?: string | null;
    image?: string | null;
    createdAt: string;
    updatedAt: string;
  } | null;
  cartId: string;
  cart?: {
    __typename: "Cart";
    id: string;
    checkedOut?: boolean | null;
    userId: string;
    user?: {
      __typename: "User";
      id: string;
      firstName: string;
      lastName?: string | null;
      email: string;
      password: string;
      phone?: string | null;
      createdAt: string;
      updatedAt: string;
    } | null;
    items?: {
      __typename: "ModelCartItemConnection";
      nextToken?: string | null;
    } | null;
    createdAt: string;
    updatedAt: string;
  } | null;
  createdAt: string;
  updatedAt: string;
};

export type OnDeleteCartItemSubscription = {
  __typename: "CartItem";
  id: string;
  quantity: number;
  itemId: string;
  item?: {
    __typename: "Item";
    id: string;
    title: string;
    price: string;
    category: string;
    description?: string | null;
    image?: string | null;
    createdAt: string;
    updatedAt: string;
  } | null;
  cartId: string;
  cart?: {
    __typename: "Cart";
    id: string;
    checkedOut?: boolean | null;
    userId: string;
    user?: {
      __typename: "User";
      id: string;
      firstName: string;
      lastName?: string | null;
      email: string;
      password: string;
      phone?: string | null;
      createdAt: string;
      updatedAt: string;
    } | null;
    items?: {
      __typename: "ModelCartItemConnection";
      nextToken?: string | null;
    } | null;
    createdAt: string;
    updatedAt: string;
  } | null;
  createdAt: string;
  updatedAt: string;
};

export type OnCreateCartSubscription = {
  __typename: "Cart";
  id: string;
  checkedOut?: boolean | null;
  userId: string;
  user?: {
    __typename: "User";
    id: string;
    firstName: string;
    lastName?: string | null;
    email: string;
    password: string;
    phone?: string | null;
    createdAt: string;
    updatedAt: string;
  } | null;
  items?: {
    __typename: "ModelCartItemConnection";
    items: Array<{
      __typename: "CartItem";
      id: string;
      quantity: number;
      itemId: string;
      cartId: string;
      createdAt: string;
      updatedAt: string;
    } | null>;
    nextToken?: string | null;
  } | null;
  createdAt: string;
  updatedAt: string;
};

export type OnUpdateCartSubscription = {
  __typename: "Cart";
  id: string;
  checkedOut?: boolean | null;
  userId: string;
  user?: {
    __typename: "User";
    id: string;
    firstName: string;
    lastName?: string | null;
    email: string;
    password: string;
    phone?: string | null;
    createdAt: string;
    updatedAt: string;
  } | null;
  items?: {
    __typename: "ModelCartItemConnection";
    items: Array<{
      __typename: "CartItem";
      id: string;
      quantity: number;
      itemId: string;
      cartId: string;
      createdAt: string;
      updatedAt: string;
    } | null>;
    nextToken?: string | null;
  } | null;
  createdAt: string;
  updatedAt: string;
};

export type OnDeleteCartSubscription = {
  __typename: "Cart";
  id: string;
  checkedOut?: boolean | null;
  userId: string;
  user?: {
    __typename: "User";
    id: string;
    firstName: string;
    lastName?: string | null;
    email: string;
    password: string;
    phone?: string | null;
    createdAt: string;
    updatedAt: string;
  } | null;
  items?: {
    __typename: "ModelCartItemConnection";
    items: Array<{
      __typename: "CartItem";
      id: string;
      quantity: number;
      itemId: string;
      cartId: string;
      createdAt: string;
      updatedAt: string;
    } | null>;
    nextToken?: string | null;
  } | null;
  createdAt: string;
  updatedAt: string;
};

@Injectable({
  providedIn: "root"
})
export class APIService {
  async CreateItem(
    input: CreateItemInput,
    condition?: ModelItemConditionInput
  ): Promise<CreateItemMutation> {
    const statement = `mutation CreateItem($input: CreateItemInput!, $condition: ModelItemConditionInput) {
        createItem(input: $input, condition: $condition) {
          __typename
          id
          title
          price
          category
          description
          image
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <CreateItemMutation>response.data.createItem;
  }
  async UpdateItem(
    input: UpdateItemInput,
    condition?: ModelItemConditionInput
  ): Promise<UpdateItemMutation> {
    const statement = `mutation UpdateItem($input: UpdateItemInput!, $condition: ModelItemConditionInput) {
        updateItem(input: $input, condition: $condition) {
          __typename
          id
          title
          price
          category
          description
          image
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <UpdateItemMutation>response.data.updateItem;
  }
  async DeleteItem(
    input: DeleteItemInput,
    condition?: ModelItemConditionInput
  ): Promise<DeleteItemMutation> {
    const statement = `mutation DeleteItem($input: DeleteItemInput!, $condition: ModelItemConditionInput) {
        deleteItem(input: $input, condition: $condition) {
          __typename
          id
          title
          price
          category
          description
          image
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <DeleteItemMutation>response.data.deleteItem;
  }
  async CreateUser(
    input: CreateUserInput,
    condition?: ModelUserConditionInput
  ): Promise<CreateUserMutation> {
    const statement = `mutation CreateUser($input: CreateUserInput!, $condition: ModelUserConditionInput) {
        createUser(input: $input, condition: $condition) {
          __typename
          id
          firstName
          lastName
          email
          password
          phone
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <CreateUserMutation>response.data.createUser;
  }
  async UpdateUser(
    input: UpdateUserInput,
    condition?: ModelUserConditionInput
  ): Promise<UpdateUserMutation> {
    const statement = `mutation UpdateUser($input: UpdateUserInput!, $condition: ModelUserConditionInput) {
        updateUser(input: $input, condition: $condition) {
          __typename
          id
          firstName
          lastName
          email
          password
          phone
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <UpdateUserMutation>response.data.updateUser;
  }
  async DeleteUser(
    input: DeleteUserInput,
    condition?: ModelUserConditionInput
  ): Promise<DeleteUserMutation> {
    const statement = `mutation DeleteUser($input: DeleteUserInput!, $condition: ModelUserConditionInput) {
        deleteUser(input: $input, condition: $condition) {
          __typename
          id
          firstName
          lastName
          email
          password
          phone
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <DeleteUserMutation>response.data.deleteUser;
  }
  async CreateCartItem(
    input: CreateCartItemInput,
    condition?: ModelCartItemConditionInput
  ): Promise<CreateCartItemMutation> {
    const statement = `mutation CreateCartItem($input: CreateCartItemInput!, $condition: ModelCartItemConditionInput) {
        createCartItem(input: $input, condition: $condition) {
          __typename
          id
          quantity
          itemId
          item {
            __typename
            id
            title
            price
            category
            description
            image
            createdAt
            updatedAt
          }
          cartId
          cart {
            __typename
            id
            checkedOut
            userId
            user {
              __typename
              id
              firstName
              lastName
              email
              password
              phone
              createdAt
              updatedAt
            }
            items {
              __typename
              nextToken
            }
            createdAt
            updatedAt
          }
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <CreateCartItemMutation>response.data.createCartItem;
  }
  async UpdateCartItem(
    input: UpdateCartItemInput,
    condition?: ModelCartItemConditionInput
  ): Promise<UpdateCartItemMutation> {
    const statement = `mutation UpdateCartItem($input: UpdateCartItemInput!, $condition: ModelCartItemConditionInput) {
        updateCartItem(input: $input, condition: $condition) {
          __typename
          id
          quantity
          itemId
          item {
            __typename
            id
            title
            price
            category
            description
            image
            createdAt
            updatedAt
          }
          cartId
          cart {
            __typename
            id
            checkedOut
            userId
            user {
              __typename
              id
              firstName
              lastName
              email
              password
              phone
              createdAt
              updatedAt
            }
            items {
              __typename
              nextToken
            }
            createdAt
            updatedAt
          }
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <UpdateCartItemMutation>response.data.updateCartItem;
  }
  async DeleteCartItem(
    input: DeleteCartItemInput,
    condition?: ModelCartItemConditionInput
  ): Promise<DeleteCartItemMutation> {
    const statement = `mutation DeleteCartItem($input: DeleteCartItemInput!, $condition: ModelCartItemConditionInput) {
        deleteCartItem(input: $input, condition: $condition) {
          __typename
          id
          quantity
          itemId
          item {
            __typename
            id
            title
            price
            category
            description
            image
            createdAt
            updatedAt
          }
          cartId
          cart {
            __typename
            id
            checkedOut
            userId
            user {
              __typename
              id
              firstName
              lastName
              email
              password
              phone
              createdAt
              updatedAt
            }
            items {
              __typename
              nextToken
            }
            createdAt
            updatedAt
          }
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <DeleteCartItemMutation>response.data.deleteCartItem;
  }
  async CreateCart(
    input: CreateCartInput,
    condition?: ModelCartConditionInput
  ): Promise<CreateCartMutation> {
    const statement = `mutation CreateCart($input: CreateCartInput!, $condition: ModelCartConditionInput) {
        createCart(input: $input, condition: $condition) {
          __typename
          id
          checkedOut
          userId
          user {
            __typename
            id
            firstName
            lastName
            email
            password
            phone
            createdAt
            updatedAt
          }
          items {
            __typename
            items {
              __typename
              id
              quantity
              itemId
              cartId
              createdAt
              updatedAt
            }
            nextToken
          }
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <CreateCartMutation>response.data.createCart;
  }
  async UpdateCart(
    input: UpdateCartInput,
    condition?: ModelCartConditionInput
  ): Promise<UpdateCartMutation> {
    const statement = `mutation UpdateCart($input: UpdateCartInput!, $condition: ModelCartConditionInput) {
        updateCart(input: $input, condition: $condition) {
          __typename
          id
          checkedOut
          userId
          user {
            __typename
            id
            firstName
            lastName
            email
            password
            phone
            createdAt
            updatedAt
          }
          items {
            __typename
            items {
              __typename
              id
              quantity
              itemId
              cartId
              createdAt
              updatedAt
            }
            nextToken
          }
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <UpdateCartMutation>response.data.updateCart;
  }
  async DeleteCart(
    input: DeleteCartInput,
    condition?: ModelCartConditionInput
  ): Promise<DeleteCartMutation> {
    const statement = `mutation DeleteCart($input: DeleteCartInput!, $condition: ModelCartConditionInput) {
        deleteCart(input: $input, condition: $condition) {
          __typename
          id
          checkedOut
          userId
          user {
            __typename
            id
            firstName
            lastName
            email
            password
            phone
            createdAt
            updatedAt
          }
          items {
            __typename
            items {
              __typename
              id
              quantity
              itemId
              cartId
              createdAt
              updatedAt
            }
            nextToken
          }
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <DeleteCartMutation>response.data.deleteCart;
  }
  async SearchItems(
    filter?: SearchableItemFilterInput,
    sort?: Array<SearchableItemSortInput | null>,
    limit?: number,
    nextToken?: string,
    from?: number,
    aggregates?: Array<SearchableItemAggregationInput | null>
  ): Promise<SearchItemsQuery> {
    const statement = `query SearchItems($filter: SearchableItemFilterInput, $sort: [SearchableItemSortInput], $limit: Int, $nextToken: String, $from: Int, $aggregates: [SearchableItemAggregationInput]) {
        searchItems(filter: $filter, sort: $sort, limit: $limit, nextToken: $nextToken, from: $from, aggregates: $aggregates) {
          __typename
          items {
            __typename
            id
            title
            price
            category
            description
            image
            createdAt
            updatedAt
          }
          nextToken
          total
          aggregateItems {
            __typename
            name
            result {
              __typename
              ... on SearchableAggregateScalarResult {
                value
              }
              ... on SearchableAggregateBucketResult {
                buckets {
                  __typename
                  key
                  doc_count
                }
              }
            }
          }
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    if (sort) {
      gqlAPIServiceArguments.sort = sort;
    }
    if (limit) {
      gqlAPIServiceArguments.limit = limit;
    }
    if (nextToken) {
      gqlAPIServiceArguments.nextToken = nextToken;
    }
    if (from) {
      gqlAPIServiceArguments.from = from;
    }
    if (aggregates) {
      gqlAPIServiceArguments.aggregates = aggregates;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <SearchItemsQuery>response.data.searchItems;
  }
  async SearchCarts(
    filter?: SearchableCartFilterInput,
    sort?: Array<SearchableCartSortInput | null>,
    limit?: number,
    nextToken?: string,
    from?: number,
    aggregates?: Array<SearchableCartAggregationInput | null>
  ): Promise<SearchCartsQuery> {
    const statement = `query SearchCarts($filter: SearchableCartFilterInput, $sort: [SearchableCartSortInput], $limit: Int, $nextToken: String, $from: Int, $aggregates: [SearchableCartAggregationInput]) {
        searchCarts(filter: $filter, sort: $sort, limit: $limit, nextToken: $nextToken, from: $from, aggregates: $aggregates) {
          __typename
          items {
            __typename
            id
            checkedOut
            userId
            user {
              __typename
              id
              firstName
              lastName
              email
              password
              phone
              createdAt
              updatedAt
            }
            items {
              __typename
              nextToken
            }
            createdAt
            updatedAt
          }
          nextToken
          total
          aggregateItems {
            __typename
            name
            result {
              __typename
              ... on SearchableAggregateScalarResult {
                value
              }
              ... on SearchableAggregateBucketResult {
                buckets {
                  __typename
                  key
                  doc_count
                }
              }
            }
          }
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    if (sort) {
      gqlAPIServiceArguments.sort = sort;
    }
    if (limit) {
      gqlAPIServiceArguments.limit = limit;
    }
    if (nextToken) {
      gqlAPIServiceArguments.nextToken = nextToken;
    }
    if (from) {
      gqlAPIServiceArguments.from = from;
    }
    if (aggregates) {
      gqlAPIServiceArguments.aggregates = aggregates;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <SearchCartsQuery>response.data.searchCarts;
  }
  async GetItem(id: string): Promise<GetItemQuery> {
    const statement = `query GetItem($id: ID!) {
        getItem(id: $id) {
          __typename
          id
          title
          price
          category
          description
          image
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      id
    };
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <GetItemQuery>response.data.getItem;
  }
  async ListItems(
    filter?: ModelItemFilterInput,
    limit?: number,
    nextToken?: string
  ): Promise<ListItemsQuery> {
    const statement = `query ListItems($filter: ModelItemFilterInput, $limit: Int, $nextToken: String) {
        listItems(filter: $filter, limit: $limit, nextToken: $nextToken) {
          __typename
          items {
            __typename
            id
            title
            price
            category
            description
            image
            createdAt
            updatedAt
          }
          nextToken
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    if (limit) {
      gqlAPIServiceArguments.limit = limit;
    }
    if (nextToken) {
      gqlAPIServiceArguments.nextToken = nextToken;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <ListItemsQuery>response.data.listItems;
  }
  async GetUser(id: string): Promise<GetUserQuery> {
    const statement = `query GetUser($id: ID!) {
        getUser(id: $id) {
          __typename
          id
          firstName
          lastName
          email
          password
          phone
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      id
    };
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <GetUserQuery>response.data.getUser;
  }
  async ListUsers(
    filter?: ModelUserFilterInput,
    limit?: number,
    nextToken?: string
  ): Promise<ListUsersQuery> {
    const statement = `query ListUsers($filter: ModelUserFilterInput, $limit: Int, $nextToken: String) {
        listUsers(filter: $filter, limit: $limit, nextToken: $nextToken) {
          __typename
          items {
            __typename
            id
            firstName
            lastName
            email
            password
            phone
            createdAt
            updatedAt
          }
          nextToken
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    if (limit) {
      gqlAPIServiceArguments.limit = limit;
    }
    if (nextToken) {
      gqlAPIServiceArguments.nextToken = nextToken;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <ListUsersQuery>response.data.listUsers;
  }
  async GetCartItem(id: string): Promise<GetCartItemQuery> {
    const statement = `query GetCartItem($id: ID!) {
        getCartItem(id: $id) {
          __typename
          id
          quantity
          itemId
          item {
            __typename
            id
            title
            price
            category
            description
            image
            createdAt
            updatedAt
          }
          cartId
          cart {
            __typename
            id
            checkedOut
            userId
            user {
              __typename
              id
              firstName
              lastName
              email
              password
              phone
              createdAt
              updatedAt
            }
            items {
              __typename
              nextToken
            }
            createdAt
            updatedAt
          }
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      id
    };
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <GetCartItemQuery>response.data.getCartItem;
  }
  async ListCartItems(
    filter?: ModelCartItemFilterInput,
    limit?: number,
    nextToken?: string
  ): Promise<ListCartItemsQuery> {
    const statement = `query ListCartItems($filter: ModelCartItemFilterInput, $limit: Int, $nextToken: String) {
        listCartItems(filter: $filter, limit: $limit, nextToken: $nextToken) {
          __typename
          items {
            __typename
            id
            quantity
            itemId
            item {
              __typename
              id
              title
              price
              category
              description
              image
              createdAt
              updatedAt
            }
            cartId
            cart {
              __typename
              id
              checkedOut
              userId
              createdAt
              updatedAt
            }
            createdAt
            updatedAt
          }
          nextToken
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    if (limit) {
      gqlAPIServiceArguments.limit = limit;
    }
    if (nextToken) {
      gqlAPIServiceArguments.nextToken = nextToken;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <ListCartItemsQuery>response.data.listCartItems;
  }
  async GetCart(id: string): Promise<GetCartQuery> {
    const statement = `query GetCart($id: ID!) {
        getCart(id: $id) {
          __typename
          id
          checkedOut
          userId
          user {
            __typename
            id
            firstName
            lastName
            email
            password
            phone
            createdAt
            updatedAt
          }
          items {
            __typename
            items {
              __typename
              id
              quantity
              itemId
              cartId
              createdAt
              updatedAt
            }
            nextToken
          }
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      id
    };
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <GetCartQuery>response.data.getCart;
  }
  async ListCarts(
    filter?: ModelCartFilterInput,
    limit?: number,
    nextToken?: string
  ): Promise<ListCartsQuery> {
    const statement = `query ListCarts($filter: ModelCartFilterInput, $limit: Int, $nextToken: String) {
        listCarts(filter: $filter, limit: $limit, nextToken: $nextToken) {
          __typename
          items {
            __typename
            id
            checkedOut
            userId
            user {
              __typename
              id
              firstName
              lastName
              email
              password
              phone
              createdAt
              updatedAt
            }
            items {
              __typename
              nextToken
            }
            createdAt
            updatedAt
          }
          nextToken
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    if (limit) {
      gqlAPIServiceArguments.limit = limit;
    }
    if (nextToken) {
      gqlAPIServiceArguments.nextToken = nextToken;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <ListCartsQuery>response.data.listCarts;
  }
  async CartItemsByCart(
    cartId: string,
    sortDirection?: ModelSortDirection,
    filter?: ModelCartItemFilterInput,
    limit?: number,
    nextToken?: string
  ): Promise<CartItemsByCartQuery> {
    const statement = `query CartItemsByCart($cartId: ID!, $sortDirection: ModelSortDirection, $filter: ModelCartItemFilterInput, $limit: Int, $nextToken: String) {
        cartItemsByCart(cartId: $cartId, sortDirection: $sortDirection, filter: $filter, limit: $limit, nextToken: $nextToken) {
          __typename
          items {
            __typename
            id
            quantity
            itemId
            item {
              __typename
              id
              title
              price
              category
              description
              image
              createdAt
              updatedAt
            }
            cartId
            cart {
              __typename
              id
              checkedOut
              userId
              createdAt
              updatedAt
            }
            createdAt
            updatedAt
          }
          nextToken
        }
      }`;
    const gqlAPIServiceArguments: any = {
      cartId
    };
    if (sortDirection) {
      gqlAPIServiceArguments.sortDirection = sortDirection;
    }
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    if (limit) {
      gqlAPIServiceArguments.limit = limit;
    }
    if (nextToken) {
      gqlAPIServiceArguments.nextToken = nextToken;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <CartItemsByCartQuery>response.data.cartItemsByCart;
  }
  OnCreateItemListener(
    filter?: ModelSubscriptionItemFilterInput
  ): Observable<
    SubscriptionResponse<Pick<__SubscriptionContainer, "onCreateItem">>
  > {
    const statement = `subscription OnCreateItem($filter: ModelSubscriptionItemFilterInput) {
        onCreateItem(filter: $filter) {
          __typename
          id
          title
          price
          category
          description
          image
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    return API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    ) as Observable<
      SubscriptionResponse<Pick<__SubscriptionContainer, "onCreateItem">>
    >;
  }

  OnUpdateItemListener(
    filter?: ModelSubscriptionItemFilterInput
  ): Observable<
    SubscriptionResponse<Pick<__SubscriptionContainer, "onUpdateItem">>
  > {
    const statement = `subscription OnUpdateItem($filter: ModelSubscriptionItemFilterInput) {
        onUpdateItem(filter: $filter) {
          __typename
          id
          title
          price
          category
          description
          image
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    return API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    ) as Observable<
      SubscriptionResponse<Pick<__SubscriptionContainer, "onUpdateItem">>
    >;
  }

  OnDeleteItemListener(
    filter?: ModelSubscriptionItemFilterInput
  ): Observable<
    SubscriptionResponse<Pick<__SubscriptionContainer, "onDeleteItem">>
  > {
    const statement = `subscription OnDeleteItem($filter: ModelSubscriptionItemFilterInput) {
        onDeleteItem(filter: $filter) {
          __typename
          id
          title
          price
          category
          description
          image
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    return API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    ) as Observable<
      SubscriptionResponse<Pick<__SubscriptionContainer, "onDeleteItem">>
    >;
  }

  OnCreateUserListener(
    filter?: ModelSubscriptionUserFilterInput
  ): Observable<
    SubscriptionResponse<Pick<__SubscriptionContainer, "onCreateUser">>
  > {
    const statement = `subscription OnCreateUser($filter: ModelSubscriptionUserFilterInput) {
        onCreateUser(filter: $filter) {
          __typename
          id
          firstName
          lastName
          email
          password
          phone
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    return API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    ) as Observable<
      SubscriptionResponse<Pick<__SubscriptionContainer, "onCreateUser">>
    >;
  }

  OnUpdateUserListener(
    filter?: ModelSubscriptionUserFilterInput
  ): Observable<
    SubscriptionResponse<Pick<__SubscriptionContainer, "onUpdateUser">>
  > {
    const statement = `subscription OnUpdateUser($filter: ModelSubscriptionUserFilterInput) {
        onUpdateUser(filter: $filter) {
          __typename
          id
          firstName
          lastName
          email
          password
          phone
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    return API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    ) as Observable<
      SubscriptionResponse<Pick<__SubscriptionContainer, "onUpdateUser">>
    >;
  }

  OnDeleteUserListener(
    filter?: ModelSubscriptionUserFilterInput
  ): Observable<
    SubscriptionResponse<Pick<__SubscriptionContainer, "onDeleteUser">>
  > {
    const statement = `subscription OnDeleteUser($filter: ModelSubscriptionUserFilterInput) {
        onDeleteUser(filter: $filter) {
          __typename
          id
          firstName
          lastName
          email
          password
          phone
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    return API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    ) as Observable<
      SubscriptionResponse<Pick<__SubscriptionContainer, "onDeleteUser">>
    >;
  }

  OnCreateCartItemListener(
    filter?: ModelSubscriptionCartItemFilterInput
  ): Observable<
    SubscriptionResponse<Pick<__SubscriptionContainer, "onCreateCartItem">>
  > {
    const statement = `subscription OnCreateCartItem($filter: ModelSubscriptionCartItemFilterInput) {
        onCreateCartItem(filter: $filter) {
          __typename
          id
          quantity
          itemId
          item {
            __typename
            id
            title
            price
            category
            description
            image
            createdAt
            updatedAt
          }
          cartId
          cart {
            __typename
            id
            checkedOut
            userId
            user {
              __typename
              id
              firstName
              lastName
              email
              password
              phone
              createdAt
              updatedAt
            }
            items {
              __typename
              nextToken
            }
            createdAt
            updatedAt
          }
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    return API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    ) as Observable<
      SubscriptionResponse<Pick<__SubscriptionContainer, "onCreateCartItem">>
    >;
  }

  OnUpdateCartItemListener(
    filter?: ModelSubscriptionCartItemFilterInput
  ): Observable<
    SubscriptionResponse<Pick<__SubscriptionContainer, "onUpdateCartItem">>
  > {
    const statement = `subscription OnUpdateCartItem($filter: ModelSubscriptionCartItemFilterInput) {
        onUpdateCartItem(filter: $filter) {
          __typename
          id
          quantity
          itemId
          item {
            __typename
            id
            title
            price
            category
            description
            image
            createdAt
            updatedAt
          }
          cartId
          cart {
            __typename
            id
            checkedOut
            userId
            user {
              __typename
              id
              firstName
              lastName
              email
              password
              phone
              createdAt
              updatedAt
            }
            items {
              __typename
              nextToken
            }
            createdAt
            updatedAt
          }
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    return API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    ) as Observable<
      SubscriptionResponse<Pick<__SubscriptionContainer, "onUpdateCartItem">>
    >;
  }

  OnDeleteCartItemListener(
    filter?: ModelSubscriptionCartItemFilterInput
  ): Observable<
    SubscriptionResponse<Pick<__SubscriptionContainer, "onDeleteCartItem">>
  > {
    const statement = `subscription OnDeleteCartItem($filter: ModelSubscriptionCartItemFilterInput) {
        onDeleteCartItem(filter: $filter) {
          __typename
          id
          quantity
          itemId
          item {
            __typename
            id
            title
            price
            category
            description
            image
            createdAt
            updatedAt
          }
          cartId
          cart {
            __typename
            id
            checkedOut
            userId
            user {
              __typename
              id
              firstName
              lastName
              email
              password
              phone
              createdAt
              updatedAt
            }
            items {
              __typename
              nextToken
            }
            createdAt
            updatedAt
          }
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    return API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    ) as Observable<
      SubscriptionResponse<Pick<__SubscriptionContainer, "onDeleteCartItem">>
    >;
  }

  OnCreateCartListener(
    filter?: ModelSubscriptionCartFilterInput
  ): Observable<
    SubscriptionResponse<Pick<__SubscriptionContainer, "onCreateCart">>
  > {
    const statement = `subscription OnCreateCart($filter: ModelSubscriptionCartFilterInput) {
        onCreateCart(filter: $filter) {
          __typename
          id
          checkedOut
          userId
          user {
            __typename
            id
            firstName
            lastName
            email
            password
            phone
            createdAt
            updatedAt
          }
          items {
            __typename
            items {
              __typename
              id
              quantity
              itemId
              cartId
              createdAt
              updatedAt
            }
            nextToken
          }
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    return API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    ) as Observable<
      SubscriptionResponse<Pick<__SubscriptionContainer, "onCreateCart">>
    >;
  }

  OnUpdateCartListener(
    filter?: ModelSubscriptionCartFilterInput
  ): Observable<
    SubscriptionResponse<Pick<__SubscriptionContainer, "onUpdateCart">>
  > {
    const statement = `subscription OnUpdateCart($filter: ModelSubscriptionCartFilterInput) {
        onUpdateCart(filter: $filter) {
          __typename
          id
          checkedOut
          userId
          user {
            __typename
            id
            firstName
            lastName
            email
            password
            phone
            createdAt
            updatedAt
          }
          items {
            __typename
            items {
              __typename
              id
              quantity
              itemId
              cartId
              createdAt
              updatedAt
            }
            nextToken
          }
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    return API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    ) as Observable<
      SubscriptionResponse<Pick<__SubscriptionContainer, "onUpdateCart">>
    >;
  }

  OnDeleteCartListener(
    filter?: ModelSubscriptionCartFilterInput
  ): Observable<
    SubscriptionResponse<Pick<__SubscriptionContainer, "onDeleteCart">>
  > {
    const statement = `subscription OnDeleteCart($filter: ModelSubscriptionCartFilterInput) {
        onDeleteCart(filter: $filter) {
          __typename
          id
          checkedOut
          userId
          user {
            __typename
            id
            firstName
            lastName
            email
            password
            phone
            createdAt
            updatedAt
          }
          items {
            __typename
            items {
              __typename
              id
              quantity
              itemId
              cartId
              createdAt
              updatedAt
            }
            nextToken
          }
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    return API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    ) as Observable<
      SubscriptionResponse<Pick<__SubscriptionContainer, "onDeleteCart">>
    >;
  }
}
