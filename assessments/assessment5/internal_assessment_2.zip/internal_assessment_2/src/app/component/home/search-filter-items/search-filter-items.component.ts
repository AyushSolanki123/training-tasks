import { Component, Output, EventEmitter, Input } from '@angular/core';

@Component({
  selector: 'app-search-filter-items',
  templateUrl: './search-filter-items.component.html',
  styleUrls: ['./search-filter-items.component.scss'],
})
export class SearchFilterItemsComponent {
  @Output() onSearchItems: EventEmitter<string> = new EventEmitter();
  @Output() onFilterItems: EventEmitter<string> = new EventEmitter();
  @Output() onResetSearch = new EventEmitter();
  @Output() onResetFilter = new EventEmitter();
  @Input() isSearch!: boolean;
  @Input() isFilter!: boolean;

  search: string = '';
  filter: string = 'All';

  searchItems() {
    console.log(this.search);
    this.isSearch = false;
    this.onSearchItems.emit(this.search);
  }

  resetSearch() {
    this.search = '';
    this.isSearch = true;
    this.onResetSearch.emit();
  }

  filterItems() {
    console.log(this.filter);
    this.isFilter = false;
    this.onFilterItems.emit(this.filter);
  }

  resetFilter() {
    this.filter = 'All';
    this.isFilter = true;
    this.onResetFilter.emit();
  }
}
