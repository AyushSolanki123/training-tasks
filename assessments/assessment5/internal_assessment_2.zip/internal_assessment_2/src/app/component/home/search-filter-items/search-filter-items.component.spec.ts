import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchFilterItemsComponent } from './search-filter-items.component';

describe('SearchFilterItemsComponent', () => {
  let component: SearchFilterItemsComponent;
  let fixture: ComponentFixture<SearchFilterItemsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearchFilterItemsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SearchFilterItemsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
