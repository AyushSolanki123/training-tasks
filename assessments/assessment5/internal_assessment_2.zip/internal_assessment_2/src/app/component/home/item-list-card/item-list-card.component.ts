import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';
import { Item } from 'src/models/Item';

@Component({
  selector: 'app-item-list-card',
  templateUrl: './item-list-card.component.html',
  styleUrls: ['./item-list-card.component.scss'],
})
export class ItemListCardComponent {
  @Input() item!: Item;

  constructor(private router: Router) {}

  navigate() {
    this.router.navigateByUrl(`/item-details/${this.item.id}`);
  }
}
