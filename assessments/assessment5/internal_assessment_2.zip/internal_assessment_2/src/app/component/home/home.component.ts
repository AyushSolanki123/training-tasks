import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { Store } from '@ngrx/store';
import { APIService } from 'src/app/API.service';
import { Item } from 'src/models/Item';
import { AppState } from 'src/store';
import { switchMap, of } from 'rxjs';
import {
  fetchItems,
  filterItems,
  resetItems,
  searchItems,
} from 'src/store/actions/home.actions';
import { selectFilteredItems } from 'src/store/selectors/home.selector';
import { ToastService } from 'src/app/service/toast/toast.service';
import { ToastEvent } from 'src/app/service/toast/Toast';
import { LocalStorageService } from 'src/app/service/local-storage/local-storage.service';
import { createCart } from 'src/store/actions/cart.actions';
import { Cart } from 'src/models/Cart';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit {
  loading: boolean = true;
  isSearch: boolean = true;
  isFilter: boolean = true;
  filteredItems!: Item[];
  currentToasts: ToastEvent[] = [];
  currentUserId!: string;

  constructor(
    private store: Store<AppState>,
    private api: APIService,
    private toastService: ToastService,
    private cdr: ChangeDetectorRef,
    private localStorageService: LocalStorageService
  ) {}

  ngOnInit(): void {
    this.loading = true;
    this.subscribeToToasts();

    this.currentUserId = <string>(
      this.localStorageService.getCurrentUserIdFromLocalStorage()
    );

    const cartId = this.localStorageService.getCurrentCartIdFromLocalStorage();
    if (!cartId) {
      this.api
        .CreateCart({ userId: this.currentUserId })
        .then((cart) => {
          const data = <Cart>cart;
          this.store.dispatch(createCart({ cart: data }));
          this.localStorageService.setCurrentCartIdInLocalStorage(cart.id);
        })
        .catch((error) => {
          console.log(error);
          this.loading = false;
          this.toastService.showErrorToast(
            'Cart Creation Failed',
            error.message
          );
        });
    } else {
      this.api.GetCart(cartId).then((cart) => {
        console.log(cart.checkedOut);
        if (cart.checkedOut) {
          this.api
            .CreateCart({ userId: this.currentUserId })
            .then((c) => {
              this.store.dispatch(createCart({ cart: <Cart>c }));
              this.localStorageService.setCurrentCartIdInLocalStorage(c.id);
            })
            .catch((error) => console.log(error));
        }
      });
    }

    this.api
      .ListItems()
      .then((response) => {
        const data = <Item[]>response.items;
        this.store.dispatch(fetchItems({ items: data }));
        this.getItemsFromStore();
      })
      .catch((error) => {
        console.log(error);
        this.toastService.showErrorToast('Items Fetch Failed', error.message);
        this.loading = false;
      });
  }

  subscribeToToasts() {
    this.toastService.toastEvents.subscribe((toasts) => {
      const currentToast: ToastEvent = {
        type: toasts.type,
        title: toasts.title,
        message: toasts.message,
      };
      this.currentToasts.push(currentToast);
      this.cdr.detectChanges();
    });
  }

  dispose(index: number) {
    this.currentToasts.splice(index, 1);
    this.cdr.detectChanges();
  }

  onResetItems() {
    this.isSearch = true;
    this.isFilter = true;
    this.store.dispatch(resetItems());
    this.getItemsFromStore();
  }

  onSearchItems(search: string) {
    this.loading = true;
    this.api
      .SearchItems({ title: { match: search } })
      .then((value) => {
        const data = <Item[]>value.items;
        this.store.dispatch(searchItems({ items: data }));
        this.getItemsFromStore();
        this.isSearch = false;
        this.loading = false;
      })
      .catch((error) => {
        console.log(error);
        this.toastService.showErrorToast('Search Failed', error.message);
        this.loading = false;
      });
  }

  onFilterItems(filter: string) {
    this.loading = true;
    this.api
      .ListItems({ category: { eq: filter } })
      .then((value) => {
        const data = <Item[]>value.items;
        this.store.dispatch(filterItems({ items: data }));
        this.getItemsFromStore();
        this.isFilter = false;
        this.loading = false;
      })
      .catch((error) => {
        console.log(error);
        this.toastService.showErrorToast(
          'Filter Items By Category Failed',
          error.message
        );
        this.loading = false;
      });
  }

  getItemsFromStore() {
    this.store
      .select(selectFilteredItems)
      .pipe(
        switchMap((items) => {
          if (items) {
            return of(items);
          } else {
            return this.store.select(selectFilteredItems);
          }
        })
      )
      .subscribe(
        (value) => {
          this.filteredItems = value;
          this.loading = false;
        },
        (error) => {
          console.log(error);
          this.loading = false;
        }
      );
  }
}
