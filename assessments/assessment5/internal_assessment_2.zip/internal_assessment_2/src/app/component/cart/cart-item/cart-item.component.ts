import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CartItem } from 'src/models/CartItem';

@Component({
  selector: 'app-cart-item',
  templateUrl: './cart-item.component.html',
  styleUrls: ['./cart-item.component.scss'],
})
export class CartItemComponent implements OnInit {
  @Input() item!: CartItem;
  @Input() index!: number;
  @Output() onRemoveFromCart: EventEmitter<{
    cartItemId: string;
    index: number;
  }> = new EventEmitter();
  @Output() onChangeItemQuantity: EventEmitter<{
    quantity: number;
    cartItemId: string;
  }> = new EventEmitter();
  quantity!: number;

  ngOnInit(): void {
    console.log(this.item);
    this.quantity = this.item.quantity;
  }

  decreaseQuantity() {
    this.quantity -= 1;
    if (this.quantity < 0) {
      this.quantity = 0;
    }
    this.onChangeItemQuantity.emit({
      quantity: this.quantity,
      cartItemId: this.item.id,
    });
  }

  increaseQuantity() {
    this.quantity += 1;
    this.onChangeItemQuantity.emit({
      quantity: this.quantity,
      cartItemId: this.item.id,
    });
  }

  removeFromCart() {
    console.log(this.item);
    this.onRemoveFromCart.emit({ cartItemId: this.item.id, index: this.index });
  }
}
