import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { of, switchMap } from 'rxjs';
import { APIService, UpdateCartInput } from 'src/app/API.service';
import { LocalStorageService } from 'src/app/service/local-storage/local-storage.service';
import { ToastEvent } from 'src/app/service/toast/Toast';
import { ToastService } from 'src/app/service/toast/toast.service';
import { Cart } from 'src/models/Cart';
import { CartItem } from 'src/models/CartItem';
import { AppState } from 'src/store';
import {
  createCart,
  deleteCartItem,
  getCartItemsByCart,
  updateCartItem,
} from 'src/store/actions/cart.actions';
import { selectCartItems } from 'src/store/selectors/cart.selector';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss'],
})
export class CartComponent implements OnInit {
  cart!: Cart;
  currentCartId!: string;
  cartItems!: CartItem[];
  loading: boolean = true;
  currentToasts!: ToastEvent[];
  isCheckOut: boolean = false;

  constructor(
    private store: Store<AppState>,
    private api: APIService,
    private toastService: ToastService,
    private cdr: ChangeDetectorRef,
    private localStorageService: LocalStorageService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loading = true;

    this.currentCartId = <string>(
      this.localStorageService.getCurrentCartIdFromLocalStorage()
    );
    this.api
      .GetCart(this.currentCartId)
      .then((value) => {
        console.log(value);
        const data = <Cart>value;
        this.cart = data;
      })
      .catch((error) => {
        console.log(error);
        this.loading = false;
        this.toastService.showErrorToast(
          'Failed to fetch Cart Details',
          error.message
        );
      });

    this.api
      .CartItemsByCart(this.currentCartId)
      .then((value) => {
        const items = <any>value.items;
        this.store.dispatch(getCartItemsByCart({ items }));
        this.store
          .select(selectCartItems)
          .pipe(
            switchMap((value) => {
              if (value) {
                return of(value);
              } else {
                return this.store.select(selectCartItems);
              }
            })
          )
          .subscribe(
            (value) => {
              console.log(value);
              this.cartItems = value;
              this.loading = false;
            },
            (error) => {
              console.log(error);
              this.toastService.showErrorToast(
                'Failed to fetch Cart Items',
                error.message
              );
              this.loading = false;
            }
          );
      })
      .catch((error) => {
        console.log(error);
        this.toastService.showErrorToast(
          'Failed to fetch Cart Items',
          error.message
        );
        this.loading = false;
      });

    this.subscribeToToasts();
  }

  calculateSubtotal(): number {
    let subTotal = 0;
    this.cartItems.forEach((cartItem) => {
      let amount = parseFloat(cartItem.item!.price) * cartItem.quantity;
      subTotal += amount;
    });
    return subTotal;
  }

  changeItemQuantity(payload: { quantity: number; cartItemId: string }) {
    this.loading = true;
    const reqBody = {
      id: payload.cartItemId,
      quantity: payload.quantity,
    };
    this.api
      .UpdateCartItem(reqBody)
      .then((cartItem) => {
        console.log(cartItem);
        this.store.dispatch(updateCartItem(reqBody));
        this.store
          .select(selectCartItems)
          .pipe(
            switchMap((value) => {
              if (value) {
                return of(value);
              } else {
                return this.store.select(selectCartItems);
              }
            })
          )
          .subscribe(
            (value) => {
              console.log(value);
              this.cartItems = value;
              this.loading = false;
            },
            (error) => {
              console.log(error);
              this.toastService.showErrorToast(
                'Failed to update Cart Item',
                error.message
              );
              this.loading = false;
            }
          );
      })
      .catch((error) => {
        console.log(error);
        this.toastService.showErrorToast(
          'Failed to update Cart Item',
          error.message
        );
        this.loading = false;
      });
  }

  removeFromCart(payload: { cartItemId: string; index: number }) {
    this.loading = true;
    console.log(payload.cartItemId, this.cartItems[payload.index].id);
    this.api
      .DeleteCartItem({ id: payload.cartItemId })
      .then((response) => {
        console.log(response);
        this.store.dispatch(deleteCartItem({ id: payload.cartItemId }));
        this.store
          .select(selectCartItems)
          .pipe(
            switchMap((value) => {
              if (value) {
                return of(value);
              } else {
                return this.store.select(selectCartItems);
              }
            })
          )
          .subscribe(
            (value) => {
              console.log(value);
              this.cartItems = value;
              this.loading = false;
            },
            (error) => {
              console.log(error);
              this.toastService.showErrorToast(
                'Failed to remove Cart Item',
                error.message
              );
              this.loading = false;
            }
          );
      })
      .catch((error) => {
        console.log(error);
        this.toastService.showErrorToast(
          'Failed to remove Cart Item',
          error.message
        );
        this.loading = false;
      });
  }

  checkOutCart() {
    this.loading = true;
    const reqBody: UpdateCartInput = {
      id: this.currentCartId,
      checkedOut: true,
    };
    this.api
      .UpdateCart(reqBody)
      .then((response) => {
        console.log(response);
        const userId = <string>(
          this.localStorageService.getCurrentUserIdFromLocalStorage()
        );
        return this.api.CreateCart({ userId });
      })
      .then((cart) => {
        console.log(cart);
        this.store.dispatch(createCart({ cart: <Cart>cart }));
        this.localStorageService.setCurrentCartIdInLocalStorage(cart.id);
        this.loading = false;
        this.isCheckOut = true;
        this.toastService.showSuccessToast(
          'Checkout Cart Successful',
          'Cart successfully checked out. Please continue shopping!!!'
        );
      })
      .catch((error) => {
        console.log(error);
        this.loading = false;
        this.toastService.showErrorToast('Cart Checkout Failed', error.message);
      });
  }

  subscribeToToasts() {
    this.toastService.toastEvents.subscribe((toasts) => {
      const currentToast: ToastEvent = {
        type: toasts.type,
        title: toasts.title,
        message: toasts.message,
      };
      this.currentToasts.push(currentToast);
      this.cdr.detectChanges();
    });
  }

  dispose(index: number) {
    this.currentToasts.splice(index, 1);
    this.cdr.detectChanges();
  }
}
