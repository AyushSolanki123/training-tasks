import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CartItem } from 'src/models/CartItem';

@Component({
  selector: 'app-list-cart-items',
  templateUrl: './list-cart-items.component.html',
  styleUrls: ['./list-cart-items.component.scss'],
})
export class ListCartItemsComponent {
  @Input() items!: CartItem[];
  @Output() onRemoveFromCart: EventEmitter<{
    cartItemId: string;
    index: number;
  }> = new EventEmitter();
  @Output() onChangeItemQuantity: EventEmitter<{
    quantity: number;
    cartItemId: string;
  }> = new EventEmitter();

  copyItem(item: CartItem) {
    return { ...item };
  }

  removeFromCart(payload: { cartItemId: string; index: number }) {
    console.log(payload.cartItemId);
    this.onRemoveFromCart.emit(payload);
  }

  changeItemQuantity(payload: { quantity: number; cartItemId: string }) {
    this.onChangeItemQuantity.emit(payload);
  }
}
