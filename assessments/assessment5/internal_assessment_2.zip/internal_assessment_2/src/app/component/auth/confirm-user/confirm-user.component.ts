import {
  Component,
  Input,
  Output,
  EventEmitter,
  OnInit,
  ChangeDetectorRef,
} from '@angular/core';
import { Auth } from 'aws-amplify';
import { ToastEvent } from 'src/app/service/toast/Toast';
import { ToastService } from 'src/app/service/toast/toast.service';

@Component({
  selector: 'app-confirm-user',
  templateUrl: './confirm-user.component.html',
  styleUrls: ['./confirm-user.component.scss'],
})
export class ConfirmUserComponent implements OnInit {
  @Output() onConfirmUser: EventEmitter<boolean> = new EventEmitter();
  @Input() email!: string;
  code!: string;
  currentToasts: ToastEvent[] = [];

  constructor(
    private toastService: ToastService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.subscribeToToasts();
  }

  subscribeToToasts() {
    this.toastService.toastEvents.subscribe((toasts) => {
      const currentToast: ToastEvent = {
        type: toasts.type,
        title: toasts.title,
        message: toasts.message,
      };
      this.currentToasts.push(currentToast);
      this.cdr.detectChanges();
    });
  }

  dispose(index: number) {
    this.currentToasts.splice(index, 1);
    this.cdr.detectChanges();
  }

  onSubmit() {
    Auth.confirmSignUp(this.email, this.code)
      .then((response) => {
        console.log(response);
        this.onConfirmUser.emit(true);
      })
      .catch((error) => {
        console.log(error);
        this.toastService.showErrorToast(
          'User Confirmation Failed',
          error.message
        );
      });
  }

  onResendCode() {
    Auth.resendSignUp(this.email)
      .then((response) => {
        console.log(response);
        console.log('Code sent SUccessfully');
        this.toastService.showSuccessToast(
          'Resend Code Successful',
          'Code Send SuccessFully'
        );
      })
      .catch((error) => {
        console.log(error);
        this.toastService.showErrorToast('Resend Code Failed', error.message);
      });
  }
}
