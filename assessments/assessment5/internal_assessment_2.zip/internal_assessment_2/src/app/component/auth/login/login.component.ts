import { Component, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent {
  @Output() onLogin: EventEmitter<{ email: string; password: string }> =
    new EventEmitter();

  isPassword: boolean = true;
  email: string = '';
  password: string = '';

  onSubmit() {
    this.onLogin.emit({ email: this.email, password: this.password });
  }
}
