import { Component, Output, EventEmitter } from '@angular/core';
import { User } from 'src/models/User';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss'],
})
export class RegisterComponent {
  @Output() onRegister: EventEmitter<User> = new EventEmitter();

  isPassword: boolean = true;
  email: string = '';
  password: string = '';
  firstName: string = '';
  lastName: string = '';
  phone: string = '';

  onSubmit() {
    const reqBody: User = {
      email: this.email,
      password: this.password,
      firstName: this.firstName,
      lastName: this.lastName,
      phone: this.phone,
    };
    this.onRegister.emit(reqBody);
  }
}
