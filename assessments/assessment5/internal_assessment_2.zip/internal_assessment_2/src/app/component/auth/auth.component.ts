import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Auth } from 'aws-amplify';
import { APIService } from 'src/app/API.service';
import { User } from 'src/models/User';
import { AppState } from 'src/store';
import { loginUser } from 'src/store/actions/auth.actions';
import { ToastService } from 'src/app/service/toast/toast.service';
import { ToastEvent } from 'src/app/service/toast/Toast';
import { LocalStorageService } from 'src/app/service/local-storage/local-storage.service';

@Component({
  selector: 'app-auth',
  templateUrl: './auth.component.html',
  styleUrls: ['./auth.component.scss'],
})
export class AuthComponent implements OnInit {
  loading: boolean = false;
  isRegister: boolean = false;
  email: string = '';
  loginActive: boolean = true;
  currentToasts: ToastEvent[] = [];

  constructor(
    private api: APIService,
    private store: Store<AppState>,
    private router: Router,
    private toastService: ToastService,
    private cdr: ChangeDetectorRef,
    private localStorageService: LocalStorageService
  ) {}

  ngOnInit(): void {
    this.subscribeToToasts();
  }

  subscribeToToasts() {
    this.toastService.toastEvents.subscribe((toasts) => {
      const currentToast: ToastEvent = {
        type: toasts.type,
        title: toasts.title,
        message: toasts.message,
      };
      this.currentToasts.push(currentToast);
      this.cdr.detectChanges();
    });
  }

  dispose(index: number) {
    this.currentToasts.splice(index, 1);
    this.cdr.detectChanges();
  }

  onLogin(payload: { email: string; password: string }) {
    this.loading = true;
    Auth.signIn(payload.email, payload.password)
      .then((response) => {
        console.log(response);
        return this.api.ListUsers({ email: { eq: payload.email } });
      })
      .then((user) => {
        console.log(user);
        const userId = <string>user.items[0]?.id;
        this.store.dispatch(loginUser());
        this.localStorageService.setCurrentUserIdInLocalStorage(userId);
        this.loading = false;
        this.toastService.showSuccessToast(
          'Login Successful',
          'User logged into the system successfully'
        );
        setTimeout(() => {
          this.router.navigateByUrl('/home');
        }, 1500);
      })
      .catch((error) => {
        console.log(error);
        this.loading = false;
        this.toastService.showErrorToast('Login Failed', error.message);
      });
  }

  onRegister(user: User) {
    this.loading = true;
    this.email = user.email;
    let _data;
    this.api
      .CreateUser(user)
      .then((response) => {
        _data = response;
        return Auth.signUp({
          username: _data.email,
          password: _data.password,
          attributes: {
            email: _data.email,
          },
          autoSignIn: {
            enabled: true,
          },
        });
      })
      .then((user) => {
        console.log(user);
        this.loading = false;
        this.isRegister = true;
        this.toastService.showSuccessToast(
          'Registration Successful',
          'Please Enter the code to confirm the user'
        );
      })
      .catch((error) => {
        console.log(error);
        this.loading = false;
        this.isRegister = false;
        this.toastService.showErrorToast('Registration Failed', error.message);
      });
  }

  onConfirmUser(userConfirmed: boolean) {
    if (userConfirmed) {
      this.loginActive = true;
      this.toastService.showSuccessToast(
        'User Confirmed Successfully',
        'Please Login now'
      );
    }
  }
}
