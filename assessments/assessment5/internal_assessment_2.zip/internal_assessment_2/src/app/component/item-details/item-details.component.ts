import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { APIService } from 'src/app/API.service';
import { LocalStorageService } from 'src/app/service/local-storage/local-storage.service';
import { ToastEvent } from 'src/app/service/toast/Toast';
import { ToastService } from 'src/app/service/toast/toast.service';
import { CartItem } from 'src/models/CartItem';
import { Item } from 'src/models/Item';
import { AppState } from 'src/store';
import { createCartItem } from 'src/store/actions/cart.actions';

@Component({
  selector: 'app-item-details',
  templateUrl: './item-details.component.html',
  styleUrls: ['./item-details.component.scss'],
})
export class ItemDetailsComponent implements OnInit {
  currentItemId!: string;
  currentCartId!: string;
  currentItem!: Item;
  loading: boolean = true;
  currentToasts: ToastEvent[] = [];

  constructor(
    private router: Router,
    private api: APIService,
    private route: ActivatedRoute,
    private cdr: ChangeDetectorRef,
    private store: Store<AppState>,
    private toastService: ToastService,
    private localStorageService: LocalStorageService
  ) {
    this.route.params.subscribe(
      (params) => {
        this.currentItemId = params['itemId'];
        console.log(params['itemId']);
      },
      (error) => {
        console.log(error);
      }
    );
  }

  ngOnInit(): void {
    this.loading = true;
    this.currentCartId = <string>(
      this.localStorageService.getCurrentCartIdFromLocalStorage()
    );
    this.subscribeToToasts();
    this.api
      .GetItem(this.currentItemId)
      .then((response) => {
        this.currentItem = response;
        console.log(response);
        this.loading = false;
      })
      .catch((error) => {
        console.log(error);
        this.loading = false;
      });
  }

  onAddToCart() {
    this.loading = true;
    const reqBody = {
      itemId: this.currentItemId,
      cartId: this.currentCartId,
      quantity: 1,
    };
    this.api
      .CreateCartItem(reqBody)
      .then((cartItem) => {
        const data = <CartItem>cartItem;
        console.log(cartItem);
        this.store.dispatch(createCartItem({ item: data }));
        this.loading = true;
        this.toastService.showSuccessToast(
          'Added to Cart',
          `Item ${this.currentItem.title} Added to cart Successfully`
        );
        setTimeout(() => {
          this.router.navigateByUrl('/cart');
        }, 1500);
      })
      .catch((error) => {
        console.log(error);
        this.loading = false;
        this.toastService.showErrorToast('Add to Cart Failed', error.message);
      });
  }

  subscribeToToasts() {
    this.toastService.toastEvents.subscribe((toasts) => {
      const currentToast: ToastEvent = {
        type: toasts.type,
        title: toasts.title,
        message: toasts.message,
      };
      this.currentToasts.push(currentToast);
      this.cdr.detectChanges();
    });
  }

  dispose(index: number) {
    this.currentToasts.splice(index, 1);
    this.cdr.detectChanges();
  }
}
