import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { of, switchMap } from 'rxjs';
import { APIService, UpdateUserInput } from 'src/app/API.service';
import { LocalStorageService } from 'src/app/service/local-storage/local-storage.service';
import { ToastEvent } from 'src/app/service/toast/Toast';
import { ToastService } from 'src/app/service/toast/toast.service';
import { User } from 'src/models/User';
import { AppState } from 'src/store';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss'],
})
export class ProfileComponent implements OnInit {
  user!: User;
  currentUserId!: string;
  loading: boolean = true;
  currentToasts: ToastEvent[] = [];
  firstName!: string;
  lastName!: string;
  email!: string;
  phone!: string;

  constructor(
    private store: Store<AppState>,
    private api: APIService,
    private toastService: ToastService,
    private cdr: ChangeDetectorRef,
    private localStorageService: LocalStorageService
  ) {}

  ngOnInit(): void {
    this.loading = true;

    this.currentUserId = <string>(
      this.localStorageService.getCurrentUserIdFromLocalStorage()
    );

    this.api
      .GetUser(this.currentUserId)
      .then((response) => {
        console.log(response);
        this.user = response;
        this.firstName = this.user.firstName;
        this.lastName = <string>this.user.lastName;
        this.email = this.user.email;
        this.phone = <string>this.user.phone;
        this.loading = false;
      })
      .catch((error) => {
        console.log(error);
        this.loading = false;
        this.toastService.showErrorToast(
          'Failed to fetch the User',
          error.message
        );
      });

    this.subscribeToToasts();
  }

  onEditProfile() {
    this.loading = true;
    const reqBody: UpdateUserInput = {
      id: this.currentUserId,
      firstName: this.firstName,
      ...(this.lastName.length && { lastName: this.lastName }),
      ...(this.phone.length && { phone: this.phone }),
    };

    this.api
      .UpdateUser(reqBody)
      .then((response) => {
        const data = <User>response;
        this.user = { ...this.user, ...data };
        this.loading = false;
        this.toastService.showSuccessToast(
          'User Profile Updated',
          'Profile Updated Succesfully'
        );
      })
      .catch((error) => {
        console.log(error);
        this.loading = false;
        this.toastService.showErrorToast(
          'Profile Updation Failed',
          error.message
        );
      });
  }

  subscribeToToasts() {
    this.toastService.toastEvents.subscribe((toasts) => {
      const currentToast: ToastEvent = {
        type: toasts.type,
        title: toasts.title,
        message: toasts.message,
      };
      this.currentToasts.push(currentToast);
      this.cdr.detectChanges();
    });
  }

  dispose(index: number) {
    this.currentToasts.splice(index, 1);
    this.cdr.detectChanges();
  }
}
