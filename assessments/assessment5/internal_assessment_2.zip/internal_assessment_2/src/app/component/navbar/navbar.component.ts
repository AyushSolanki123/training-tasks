import { Component, OnInit } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Auth } from 'aws-amplify';
import { AppState } from 'src/store';
import { logoutUser } from 'src/store/actions/auth.actions';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss'],
})
export class NavbarComponent implements OnInit {
  currentRoute: string = '';

  constructor(private store: Store<AppState>, private router: Router) {}

  ngOnInit() {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.currentRoute = event.url;
      }
    });
  }

  navigateToCart() {
    this.router.navigateByUrl('/cart');
  }

  navigateToProfile() {
    this.router.navigateByUrl('/user-profile');
  }

  logout() {
    Auth.signOut()
      .then(() => {
        this.store.dispatch(logoutUser());
        this.router.navigateByUrl('/auth');
      })
      .catch((error) => {
        console.log(error);
      });
  }
}
