import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AmplifyAuthenticatorModule } from '@aws-amplify/ui-angular';
import { AppRoutingModule } from './app-routing.module';
import { StoreModule } from '@ngrx/store';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { reducers } from 'src/store';
import { LoadingComponent } from './component/loading/loading.component';
import { AuthComponent } from './component/auth/auth.component';
import { LoginComponent } from './component/auth/login/login.component';
import { RegisterComponent } from './component/auth/register/register.component';
import { HomeComponent } from './component/home/home.component';
import { NavbarComponent } from './component/navbar/navbar.component';
import { ConfirmUserComponent } from './component/auth/confirm-user/confirm-user.component';
import { ToastComponent } from './component/toast/toast.component';
import { SearchFilterItemsComponent } from './component/home/search-filter-items/search-filter-items.component';
import { ListItemsComponent } from './component/home/list-items/list-items.component';
import { ItemListCardComponent } from './component/home/item-list-card/item-list-card.component';
import { ItemDetailsComponent } from './component/item-details/item-details.component';
import { ProfileComponent } from './component/profile/profile.component';
import { CartComponent } from './component/cart/cart.component';
import { ListCartItemsComponent } from './component/cart/list-cart-items/list-cart-items.component';
import { CartItemComponent } from './component/cart/cart-item/cart-item.component';

@NgModule({
  declarations: [
    AppComponent,
    LoadingComponent,
    AuthComponent,
    LoginComponent,
    RegisterComponent,
    HomeComponent,
    NavbarComponent,
    ConfirmUserComponent,
    ToastComponent,
    SearchFilterItemsComponent,
    ListItemsComponent,
    ItemListCardComponent,
    ItemDetailsComponent,
    ProfileComponent,
    CartComponent,
    ListCartItemsComponent,
    CartItemComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    AmplifyAuthenticatorModule,
    StoreModule.forRoot(reducers),
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
