import { createAction, props } from '@ngrx/store';
import { Cart } from 'src/models/Cart';
import { CartItem } from 'src/models/CartItem';

export const CREATE_CART = '[Cart Component] CREATE_CART';
export const FETCH_CARTS = '[Cart Component] FETCH_CARTS';
export const CHECKOUT_CART = '[Cart Component] CHECKOUT_CART';

export const CREATE_CART_ITEM = '[Cart Component] CREATE_CART_ITEM';
export const UPDATE_CART_ITEM = '[Cart Component] UPDATE_CART_ITEM';
export const DELETE_CART_ITEM = '[Cart Component] DELETE_CART_ITEM';
export const GET_CART_ITEM_BY_CART = '[Cart Component] GET_CART_ITEM_BY_CART';

export const fetchCarts = createAction(FETCH_CARTS, props<{ carts: Cart[] }>());
export const createCart = createAction(CREATE_CART, props<{ cart: Cart }>());

export const createCartItem = createAction(
  CREATE_CART_ITEM,
  props<{ item: CartItem }>()
);
export const updateCartItem = createAction(
  UPDATE_CART_ITEM,
  props<{ id: string; quantity: number }>()
);
export const deleteCartItem = createAction(
  DELETE_CART_ITEM,
  props<{ id: string }>()
);
export const getCartItemsByCart = createAction(
  GET_CART_ITEM_BY_CART,
  props<{ items: CartItem[] }>()
);
