import { createAction, props } from '@ngrx/store';

export const LOGIN_USER = '[Auth Component] LOGIN_USER';
export const REGISTER_USER = '[Auth Component] REGISTER_USER';
export const LOGOUT_USER = '[Auth Component] LOGOUT_USER';

export const loginUser = createAction(LOGIN_USER);
export const logoutUser = createAction(LOGOUT_USER);
