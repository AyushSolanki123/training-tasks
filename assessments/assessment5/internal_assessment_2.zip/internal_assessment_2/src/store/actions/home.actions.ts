import { createAction, props } from '@ngrx/store';
import { Item } from 'src/models/Item';

export const FETCH_ITEMS = '[Home Component] FETCH_ITEMS';
export const RESET_ITEMS = '[Home Component] RESET_ITEMS';
export const FILTER_ITEMS = '[Home Component] FILTER_ITEMS';
export const SEARCH_ITEMS = '[Home Component] SEARCH_ITEMS';

export const fetchItems = createAction(FETCH_ITEMS, props<{ items: Item[] }>());
export const searchItems = createAction(
  SEARCH_ITEMS,
  props<{ items: Item[] }>()
);
export const filterItems = createAction(
  FILTER_ITEMS,
  props<{ items: Item[] }>()
);
export const resetItems = createAction(RESET_ITEMS);
