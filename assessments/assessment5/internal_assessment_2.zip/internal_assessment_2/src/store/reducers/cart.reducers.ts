import { createReducer, on } from '@ngrx/store';
import { Cart } from 'src/models/Cart';
import { CartItem } from 'src/models/CartItem';
import {
  createCart,
  createCartItem,
  deleteCartItem,
  fetchCarts,
  getCartItemsByCart,
  updateCartItem,
} from '../actions/cart.actions';

export interface CartState {
  carts: Cart[];
  currentCartId: string;
  isCartCheckedOut: boolean;
  cartItems: CartItem[];
}

const initialState: CartState = {
  carts: [],
  cartItems: [],
  currentCartId: '',
  isCartCheckedOut: true,
};

const _cartReducer = createReducer(
  initialState,
  on(createCart, (state, { cart }) => {
    return { ...state, carts: [...state.carts, cart], currentCartId: cart.id };
  }),
  on(createCartItem, (state, { item }) => {
    return {
      ...state,
      cartItems: [...state.cartItems, item],
    };
  }),
  on(updateCartItem, (state, { id, quantity }) => {
    return {
      ...state,
      cartItems: state.cartItems.map((item) =>
        item.id == id ? { ...item, quantity } : item
      ),
    };
  }),
  on(deleteCartItem, (state, { id }) => {
    return {
      ...state,
      cartItems: state.cartItems.filter((item) => item.id != id),
    };
  }),
  on(getCartItemsByCart, (state, { items }) => {
    return {
      ...state,
      cartItems: items,
    };
  }),
  on(fetchCarts, (state, { carts }) => {
    return {
      ...state,
      carts: carts,
    };
  })
);

export const cartReducer = (state: any, action: any) => {
  return _cartReducer(state, action);
};
