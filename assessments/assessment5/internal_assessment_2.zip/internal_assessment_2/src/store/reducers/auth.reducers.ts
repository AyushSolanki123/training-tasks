import { createReducer, on } from '@ngrx/store';
import { loginUser, logoutUser } from '../actions/auth.actions';

export interface AuthState {
  isLoggedIn: boolean;
}

const initialState: AuthState = {
  isLoggedIn: false,
};

const _authReducer = createReducer(
  initialState,
  on(loginUser, (state) => {
    return {
      ...state,
      isLoggedIn: true,
    };
  }),
  on(logoutUser, () => initialState)
);

export const authReducer = (state: any, action: any) => {
  return _authReducer(state, action);
};
