import { createReducer, on } from '@ngrx/store';
import { Item } from 'src/app/API.service';
import {
  fetchItems,
  filterItems,
  resetItems,
  searchItems,
} from '../actions/home.actions';

export interface HomeState {
  items: Item[];
  filteredItems: Item[];
}

const initialState: HomeState = {
  items: [],
  filteredItems: [],
};

const _homeReducer = createReducer(
  initialState,
  on(fetchItems, (state, { items }) => {
    return {
      ...state,
      items: items,
      filteredItems: items,
    };
  }),
  on(searchItems, (state, { items }) => {
    return {
      ...state,
      filteredItems: items,
    };
  }),
  on(filterItems, (state, { items }) => {
    return {
      ...state,
      filteredItems: items,
    };
  }),
  on(resetItems, (state) => {
    return {
      ...state,
      filteredItems: state.items,
    };
  })
);

export const homeReducer = (state: any, action: any) => {
  return _homeReducer(state, action);
};
