import { createFeatureSelector, createSelector } from '@ngrx/store';
import { AppState } from '..';
import { CartState } from '../reducers/cart.reducers';

const selectCartState = createFeatureSelector<AppState, CartState>('cartState');

export const selectCarts = createSelector(
  selectCartState,
  (state: CartState) => state.carts
);

export const selectCurrentCartId = createSelector(
  selectCartState,
  (state: CartState) => state.currentCartId
);

export const selectCartItems = createSelector(
  selectCartState,
  (state: CartState) => state.cartItems
);

export const selectIsCartCheckedOut = createSelector(
  selectCartState,
  (state: CartState) => state.isCartCheckedOut
);
