import { createFeatureSelector, createSelector } from '@ngrx/store';
import { AppState } from '..';
import { HomeState } from '../reducers/home.reducers';

const selectHomeState = createFeatureSelector<AppState, HomeState>('homeState');

export const selectItems = createSelector(
  selectHomeState,
  (state: HomeState) => state.items
);

export const selectFilteredItems = createSelector(
  selectHomeState,
  (state: HomeState) => state.filteredItems
);
