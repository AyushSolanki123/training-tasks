import { ActionReducerMap } from '@ngrx/store';
import { AuthState, authReducer } from './reducers/auth.reducers';
import { HomeState, homeReducer } from './reducers/home.reducers';
import { CartState, cartReducer } from './reducers/cart.reducers';

export interface AppState {
  authState: AuthState;
  homeState: HomeState;
  cartState: CartState;
}

export const reducers: ActionReducerMap<AppState> = {
  authState: authReducer,
  homeState: homeReducer,
  cartState: cartReducer,
};
