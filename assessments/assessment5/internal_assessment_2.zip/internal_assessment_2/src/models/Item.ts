export interface Item {
  __typename: 'Item';
  id: string;
  title: string;
  price: string;
  category: string;
  description?: string | null;
  image?: string | null;
  createdAt: string;
  updatedAt: string;
}
