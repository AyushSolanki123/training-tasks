export interface User {
  id?: string | null;
  firstName: string;
  lastName?: string | null;
  email: string;
  password: string;
  phone?: string | null;
  createdAt?: string | null;
  updatedAt?: string | null;
}
