import { Cart } from './Cart';
import { Item } from './Item';

export interface CartItem {
  __typename: 'CartItem';
  id: string;
  quantity: number;
  itemId: string;
  item?: Item | null;
  cartId: string;
  cart?: Cart | null;
  createdAt: string;
  updatedAt: string;
}
