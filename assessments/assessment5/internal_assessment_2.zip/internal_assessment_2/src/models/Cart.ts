import { CartItem } from './CartItem';
import { User } from './User';

export interface Cart {
  __typename: 'Cart';
  id: string;
  userId: string;
  user?: User | null;
  items?: [CartItem] | null;
  createdAt: string;
  updatedAt: string;
}
